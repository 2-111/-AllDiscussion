package com.ad.tools;

import java.util.ArrayList;
import java.util.List;

public class Page {
	// 1.ÿҳ��ʾ����(everyPage)
	private int everyPage;
	// 2.�ܼ�¼��(totalCount)
	private long totalCount;
	// 3.��ҳ��(totalPage)
	private long totalPage;
	// 4.��ǰҳ(currentPage)
	private int currentPage;
	// 5.��ʼ��(beginIndex)
	private int beginIndex;
	// 6.�Ƿ�����һҳ(hasPrePage)
	private boolean hasPrePage;
	// 7.�Ƿ�����һҳ(hasNextPage)
	private boolean hasNextPage;
	private List PageList;

	public Page(int everyPage, long totalCount, long totalPage, int currentPage, int beginIndex, boolean hasPrePage,
			boolean hasNextPage,List PageList) {
		this.everyPage = everyPage;
		this.totalCount = totalCount;
		this.totalPage = totalPage;
		this.currentPage = currentPage;
		this.beginIndex = beginIndex;
		this.hasPrePage = hasPrePage;
		this.hasNextPage = hasNextPage;
		this.PageList=PageList;
	}

	// ���캯����Ĭ��
	public Page() {
	}

	public int getEveryPage() {
		return everyPage;
	}

	public void setEveryPage(int everyPage) {
		this.everyPage = everyPage;
	}

	public long getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(long totalCount) {
		this.totalCount = totalCount;
	}

	public long getTotalPage() {
		return totalPage;
	}

	public void setTotalPage(long totalPage) {
		this.totalPage = totalPage;
	}

	public int getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}

	public int getBeginIndex() {
		return beginIndex;
	}

	public void setBeginIndex(int beginIndex) {
		this.beginIndex = beginIndex;
	}

	public boolean isHasPrePage() {
		return hasPrePage;
	}

	public void setHasPrePage(boolean hasPrePage) {
		this.hasPrePage = hasPrePage;
	}

	public boolean isHasNextPage() {
		return hasNextPage;
	}

	public void setHasNextPage(boolean hasNextPage) {
		this.hasNextPage = hasNextPage;
	}

	public List getPageList() {
		return PageList;
	}

	public void setPageList(List pageList) {
		PageList = pageList;
	}

	// ���췽�������������Խ�������
	public Page (int everyPage, long totalCount, int currentPage) {
		everyPage = getEveryPage(everyPage);
		currentPage = getCurrentPage(currentPage);
		long totalPage = getTotalPage(everyPage, totalCount);
		int beginIndex = getBeginIndex(everyPage, currentPage);
		boolean hasPrePage = getHasPrePage(currentPage);
		boolean hasNextPage = getHasNextPage(totalPage, currentPage);
		List PageList=numberShow(totalPage, currentPage);
	}

	public Page (Page page, long totalCount) {
		int everyPage = getEveryPage(page.getEveryPage());
		int currentPage = getCurrentPage(page.getCurrentPage());
		long totalPage = getTotalPage(everyPage, totalCount);
		int beginIndex = getBeginIndex(everyPage, currentPage);
		boolean hasPrePage = getHasPrePage(currentPage);
		boolean hasNextPage = getHasNextPage(totalPage, currentPage);
		List PageList=numberShow(totalPage, currentPage);
	}

	// ����ÿҳ��ʾ��¼��
	public int getEveryPage(int everyPage) {
		return everyPage == 0 ? 10 : everyPage;
	}

	// ���õ�ǰҳ
	public int getCurrentPage(int currentPage) {
		return currentPage == 0 ? 1 : currentPage;
	}

	// ������ҳ��,��Ҫ�ܼ�¼����ÿҳ��ʾ����
	public long getTotalPage(int everyPage, long totalCount) {
		long totalPage = 0;
		if (totalCount % everyPage == 0) {
			totalPage = totalCount / everyPage;
		} else {
			totalPage = totalCount / everyPage + 1;
		}
		return totalPage;
	}

	// ������ʼ�㣬��Ҫÿҳ��ʾ���٣���ǰҳ
	public int getBeginIndex(int everyPage, int currentPage) {
		return (currentPage - 1) * everyPage;
	}

	// �����Ƿ�����һҳ����Ҫ��ǰҳ
	public boolean getHasPrePage(int currentPage) {
		return currentPage == 1 ? false : true;
	}

	// �����Ƿ�����һ������Ҫ��ҳ���͵�ǰҳ
	public  boolean getHasNextPage(long totalPage, int currentPage) {
		return currentPage == totalPage || totalPage == 0 ? false : true;
	}
	public  List  numberShow(long totalPage ,int currentPage )
	{
		List list=(List) new ArrayList();
		if(currentPage<5)
		{
			if(totalPage>5)
			{
			for(int i=1;i<=5;i++)
			{
				
				list.add(i);
			}
			}
			else
			{
				for(int i=1;i<=totalPage;i++)
				{
					
					list.add(i);
				}
				
			}
		}
		else
		{
			list.add(currentPage-2);
			list.add(currentPage-1);
			list.add(currentPage);
			if((currentPage+1)<=totalPage)
			{
				list.add(currentPage+1);
				currentPage=currentPage+1;
			}
			if((currentPage+1)<=totalPage)
			{
				list.add(currentPage+1);
				currentPage=currentPage-2;
			}
			
		}
		return list;
		
	}
	
}
