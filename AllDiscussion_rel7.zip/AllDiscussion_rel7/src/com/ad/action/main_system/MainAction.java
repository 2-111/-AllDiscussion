package com.ad.action.main_system;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.struts2.ServletActionContext;

import com.ad.service.main_system.MainManager;
import com.ad.tools.Page;
import com.model.AllDiscussionChat;
import com.model.AllDiscussionConversation;
import com.model.AllDiscussionCrads;
import com.model.AllDiscussionUser;
import com.model.AllDiscussionVip;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class MainAction extends ActionSupport {
	@Resource
	private MainManager maimManager;
	private List info;
	private String context;
	private String title;
	private static int BUFFER_SIZE = 1024 * 1024;
	private String path;
	private File upload;
	private String uploadFileName;
	private String uploadContentType;
	private String savePath;
	private int currentPage;
	private List pageList;
	@Resource
	private Page page;
	private static int ERVEY_PAGE = 2;
	private AllDiscussionVip personal;
	private String cardId;
	private List titleCard;
	private String personalId;
	private int collflag;
	private Set setList;
	private int goodFlag;
	private List friendList;
	private int friendflag;
	private int makePublicFlag;
	private String parentId;

	public String makePublicConAction() {
		AllDiscussionConversation adc = new AllDiscussionConversation();
		Map session = ActionContext.getContext().getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		AllDiscussionCrads adcr = new AllDiscussionCrads();
		adc.setContext(context);
		adc.setDeleteFlag(0);
		adc.setHot(0);
		adc.setTitle(title);
		adc.setChatTag(0);
		adc.setDeleteFlag(0);
		adcr.setAllDiscussionConversation(adc);
		adcr.setContext(null);
		adcr.setDeleteFlag(0);
		adcr.setGoods(0);
		adcr.setAllDiscussionVip(adu.getAllDiscussionVip());
		adcr.setRelyN(0);
		adcr.setTitle(null);
		adcr.setLevel(0);
		Timestamp d = new Timestamp(System.currentTimeMillis());
		adcr.setNowTime(d);
		adcr.setUpdateTime(d);
		adcr.setParentId("0");
		adcr.setTidings(0);
		if (maimManager.makePublicCon(adcr)) {

			return "makePublicCon_success";

		} else {

			return "makePublicCon_error";
		}
	}

	public String makePublicCra_RemarAction() {
		AllDiscussionCrads adcr = new AllDiscussionCrads();
		Map session = ActionContext.getContext().getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		this.uploadImg();
		adcr.setAllDiscussionVip(adu.getAllDiscussionVip());
		adcr.setContext(context);
		adcr.setDeleteFlag(0);
		adcr.setGoods(0);
		adcr.setRelyN(0);
		adcr.setTitle(title);
		Timestamp d = new Timestamp(System.currentTimeMillis());
		adcr.setNowTime(d);
		adcr.setUpdateTime(d);
		adcr.setParentId(cardId);
		adcr.setImage(path);
		adcr.setTidings(0);
		if (makePublicFlag == 1) {
			adcr.setLevel(1);
			maimManager.makePublicCra_Remar(cardId, adcr);
			return "makePublicCra_Remar_success_card";
		} else if (makePublicFlag == 2) {
			adcr.setLevel(2);
			maimManager.makePublicCra_Remar(cardId, adcr);
			return "makePublicCra_Remar_success_Remar";
		} else {
			adcr.setLevel(3);
			maimManager.makePublicCra_Remar(cardId, adcr);
			return "makePublicCra_Remar_success_Remar_Rem";
		}
	}

	@SuppressWarnings("unchecked")
	public String showConversationAction() {
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		session.put("currentPage", currentPage);
		long totalCount = maimManager.getCountConversation();
		System.out.println(currentPage);
		page.setEveryPage(ERVEY_PAGE);
		page.setCurrentPage(currentPage);
		page.setTotalCount(totalCount);
		// totalPage = page.getTotalPage();
		setList = maimManager.showCollection();
		if (setList.isEmpty()) {
			collflag = 1;
		} else {
			collflag = 0;
		}
		friendList = maimManager.showFriend();
		if (friendList.isEmpty()) {
			friendflag = 1;
		} else {
			friendflag = 0;
		}
		pageList = page.numberShow(page.getTotalPage(ERVEY_PAGE, totalCount), currentPage);
		info = maimManager.showConversation(page.getBeginIndex(ERVEY_PAGE, currentPage), ERVEY_PAGE);
		return "showConversation_success";
	}

	public String preShowConversationAction() {
		currentPage = 1;
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		session.put("currentPage", currentPage);
		long totalCount = maimManager.getCountConversation();
		// System.out.println(currentPage);
		page.setEveryPage(ERVEY_PAGE);
		page.setCurrentPage(currentPage);
		page.setTotalCount(totalCount);
		// totalPage = page.getTotalPage();

		setList = maimManager.showCollection();
		if (setList.isEmpty()) {
			collflag = 1;
		} else {
			collflag = 0;
		}

		friendList = maimManager.showFriend();
		if (friendList.isEmpty()) {
			friendflag = 1;
		} else {
			friendflag = 0;
		}
		pageList = page.numberShow(page.getTotalPage(ERVEY_PAGE, totalCount), currentPage);
		info = maimManager.showConversation(page.getBeginIndex(ERVEY_PAGE, currentPage), ERVEY_PAGE);
		return "preShowConversation_success";
	}

	public String showCardAction() {

		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		session.put("currentPage", currentPage);
		cardId = (String) session.get("showCardId");
		long totalCount = maimManager.getCountCard(cardId);
		//System.out.println(cardId);
		page.setEveryPage(ERVEY_PAGE);
		page.setCurrentPage(currentPage);
		page.setTotalCount(totalCount);
		// totalPage = page.getTotalPage();
		setList = maimManager.showCollection();
		if (setList.isEmpty()) {
			collflag = 1;
		} else {
			collflag = 0;
		}
		friendList = maimManager.showFriend();
		if (friendList.isEmpty()) {
			friendflag = 1;
		} else {
			friendflag = 0;
		}
		pageList = page.numberShow(page.getTotalPage(ERVEY_PAGE, totalCount), currentPage);
		info = maimManager.showCard(page.getBeginIndex(ERVEY_PAGE, currentPage), ERVEY_PAGE, cardId);
		titleCard = maimManager.title(cardId);
		return "showCard_success";

	}

	public String preShowCardAction() {
		currentPage = 1;
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		session.put("currentPage", currentPage);
		session.put("showCardId", cardId);
		long totalCount = maimManager.getCountCard(cardId);
		System.out.println(currentPage);
		page.setEveryPage(ERVEY_PAGE);
		page.setCurrentPage(currentPage);
		page.setTotalCount(totalCount);
		// totalPage = page.getTotalPage();
		setList = maimManager.showCollection();
		if (setList.isEmpty()) {
			collflag = 1;
		} else {
			collflag = 0;
		}
		friendList = maimManager.showFriend();
		if (friendList.isEmpty()) {
			friendflag = 1;
		} else {
			friendflag = 0;
		}
		pageList = page.numberShow(page.getTotalPage(ERVEY_PAGE, totalCount), currentPage);
		info = maimManager.showCard(page.getBeginIndex(ERVEY_PAGE, currentPage), ERVEY_PAGE, cardId);
		titleCard = maimManager.title(cardId);
		return "preShowCard_success";

	}

	public String preShowRemarkAction() {
		currentPage = 1;
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		session.put("currentPage", currentPage);
		session.put("showRemarkId", cardId);
		long totalCount = maimManager.getCountCard(cardId);
		System.out.println(currentPage);
		page.setEveryPage(ERVEY_PAGE);
		page.setCurrentPage(currentPage);
		page.setTotalCount(totalCount);
		// totalPage = page.getTotalPage();
		setList = maimManager.showCollection();
		if (setList.isEmpty()) {
			collflag = 1;
		} else {
			collflag = 0;
		}
		friendList = maimManager.showFriend();
		if (friendList.isEmpty()) {
			friendflag = 1;
		} else {
			friendflag = 0;
		}
		pageList = page.numberShow(page.getTotalPage(ERVEY_PAGE, totalCount), currentPage);
		info = maimManager.showRemark(page.getBeginIndex(ERVEY_PAGE, currentPage), ERVEY_PAGE, cardId);
		titleCard = maimManager.title(cardId);
		return "preShowRemark_success";
	}

	public String showRemarkAction() {
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		session.put("currentPage", currentPage);
		cardId = (String) session.get("showRemarkId");
		long totalCount = maimManager.getCountCard(cardId);
		System.out.println(cardId);
		page.setEveryPage(ERVEY_PAGE);
		page.setCurrentPage(currentPage);
		page.setTotalCount(totalCount);
		setList = maimManager.showCollection();
		if (setList.isEmpty()) {
			collflag = 1;
		} else {
			collflag = 0;
		}
		friendList = maimManager.showFriend();
		if (friendList.isEmpty()) {
			friendflag = 1;
		} else {
			friendflag = 0;
		}
		// totalPage = page.getTotalPage();
		pageList = page.numberShow(page.getTotalPage(ERVEY_PAGE, totalCount), currentPage);
		info = maimManager.showRemark(page.getBeginIndex(ERVEY_PAGE, currentPage), ERVEY_PAGE, cardId);
		titleCard = maimManager.title(cardId);
		return "showRemark_success";

	}

	public String showRemarkRemAction() {

		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		session.put("currentPage", currentPage);
		cardId = (String) session.get("showRemarkRemId");
		long totalCount = maimManager.getCountCard(cardId);
		System.out.println(cardId);
		page.setEveryPage(ERVEY_PAGE);
		page.setCurrentPage(currentPage);
		page.setTotalCount(totalCount);
		// totalPage = page.getTotalPage();
		setList = maimManager.showCollection();
		if (setList.isEmpty()) {
			collflag = 1;
		} else {
			collflag = 0;
		}
		friendList = maimManager.showFriend();
		if (friendList.isEmpty()) {
			friendflag = 1;
		} else {
			friendflag = 0;
		}
		pageList = page.numberShow(page.getTotalPage(ERVEY_PAGE, totalCount), currentPage);
		info = maimManager.showRemarkRem(page.getBeginIndex(ERVEY_PAGE, currentPage), ERVEY_PAGE, cardId);
		titleCard = maimManager.title(cardId);
		return "showRemarkRem_success";

	}

	public String preShowRemarkRemAction() {

		currentPage = 1;
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		session.put("currentPage", currentPage);
		session.put("showRemarkRemId", cardId);
		long totalCount = maimManager.getCountCard(cardId);
		System.out.println(cardId);
		page.setEveryPage(ERVEY_PAGE);
		page.setCurrentPage(currentPage);
		page.setTotalCount(totalCount);
		// totalPage = page.getTotalPage();
		setList = maimManager.showCollection();
		if (setList.isEmpty()) {
			collflag = 1;
		} else {
			collflag = 0;
		}
		friendList = maimManager.showFriend();
		if (friendList.isEmpty()) {
			friendflag = 1;
		} else {
			friendflag = 0;
		}
		pageList = page.numberShow(page.getTotalPage(ERVEY_PAGE, totalCount), currentPage);
		info = maimManager.showRemarkRem(page.getBeginIndex(ERVEY_PAGE, currentPage), ERVEY_PAGE, cardId);
		titleCard = maimManager.title(cardId);
		return "preShowRemarkRem_success";

	}

	public void uploadImg() {
		try {

			if (upload != null) {
				InputStream in = new FileInputStream(getUpload());
				String imageFileName = new Date().getTime() + getExtention(uploadFileName);
				path = ServletActionContext.getServletContext().getRealPath(this.getSavePath()) + "/" + imageFileName;
				OutputStream out = new FileOutputStream(path);
				int count = 0;
				byte buffer[] = new byte[BUFFER_SIZE];
				while ((count = in.read(buffer)) > 0) {

					out.write(buffer, 0, count);

				}
				in.close();
				out.close();
				path = "image/" + imageFileName;
			} else {
				path = null;

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static String getExtention(String fileName) {
		int pos = fileName.lastIndexOf(".");
		return fileName.substring(pos);

	}

	public String showPersonalAction() {
		personal = maimManager.personal(personalId);
		return "showPersonal_success";
	}

	public String collectionAction() {
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		maimManager.collectionCC(cardId, adu);
		AllDiscussionCrads card=maimManager.getCard(cardId);
		parentId=card.getParentId();

		if (makePublicFlag == 1) {
			return "collectionAction_success_card";
		} else {
			return "collectionAction_success_Conversation";
		}
	}

	public String cancelCollectionAction() {

		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		maimManager.cancelCollection(cardId, adu);
		AllDiscussionCrads card=maimManager.getCard(cardId);
		parentId=card.getParentId();
		if (makePublicFlag == 1) {
			return "cancelCollectionAction_success_card";
		}

		else {
			return "cancelCollectionAction_success_Conversation";
		}
	}

	public String changeGoodAction() {
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		maimManager.changegood(goodFlag, cardId);
		AllDiscussionCrads card=maimManager.getCard(cardId);
		parentId=card.getParentId();
		if (makePublicFlag == 1) {
			return "changeGoodAction_success_card";
		}

		else if(makePublicFlag==2)
		{
			return "changeGoodAction_success_Remark";
			
		}
		else {
			return "changeGoodAction_success_Conversation";
		}
	}

	public String addHateObjectAction() {
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		maimManager.addHateObject(adu, cardId);
		return "addHateObjectAction_success";
		
		
	}

	public String addFriendAction() {
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		AllDiscussionChat adC = new AllDiscussionChat();
		adC.setAllDiscussionVip(adu.getAllDiscussionVip());
		adC.setDeleteFlag(0);
		adC.setParentId("0");
		Timestamp d = new Timestamp(System.currentTimeMillis());
		adC.setTime(d);

		maimManager.addFriend(adu, cardId, adC);
		return "addFriendAction_success";

	}

	public String addChatObjectAction() {
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		AllDiscussionChat adC = new AllDiscussionChat();
		adC.setAllDiscussionVip(adu.getAllDiscussionVip());
		adC.setDeleteFlag(0);
		adC.setParentId("0");
		Timestamp d = new Timestamp(System.currentTimeMillis());
		adC.setTime(d);
		maimManager.addChatObject(adu, cardId, adC);
		return "addChatObject_success";
	}

	
	public String getParentId() {
		return parentId;
	}

	public void setParentId(String parentId) {
		this.parentId = parentId;
	}

	public int getMakePublicFlag() {
		return makePublicFlag;
	}

	public void setMakePublicFlag(int makePublicFlag) {
		this.makePublicFlag = makePublicFlag;
	}

	public int getFriendflag() {
		return friendflag;
	}

	public void setFriendflag(int friendflag) {
		this.friendflag = friendflag;
	}

	public List getFriendList() {
		return friendList;
	}

	public void setFriendList(List friendList) {
		this.friendList = friendList;
	}

	public int getGoodFlag() {
		return goodFlag;
	}

	public void setGoodFlag(int goodFlag) {
		this.goodFlag = goodFlag;
	}

	public Set getSetList() {
		return setList;
	}

	public void setSetList(Set setList) {
		this.setList = setList;
	}

	public List getInfo() {
		return info;
	}

	public void setInfo(List info) {
		this.info = info;
	}

	public String getContext() {
		return context;
	}

	public void setContext(String context) {
		this.context = context;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public File getUpload() {
		return upload;
	}

	public void setUpload(File upload) {
		this.upload = upload;
	}

	public String getUploadFileName() {
		return uploadFileName;
	}

	public void setUploadFileName(String uploadFileName) {
		this.uploadFileName = uploadFileName;
	}

	public String getUploadContentType() {
		return uploadContentType;
	}

	public void setUploadContentType(String uploadContentType) {
		this.uploadContentType = uploadContentType;
	}

	public String getSavePath() {
		return savePath;
	}

	public void setSavePath(String savePath) {
		this.savePath = savePath;
	}

	public int getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}

	public List getPageList() {
		return pageList;
	}

	public void setPageList(List pageList) {
		this.pageList = pageList;
	}

	public Page getPage() {
		return page;
	}

	public void setPage(Page page) {
		this.page = page;
	}

	public AllDiscussionVip getPersonal() {
		return personal;
	}

	public void setPersonal(AllDiscussionVip personal) {
		this.personal = personal;
	}

	public String getCardId() {
		return cardId;
	}

	public void setCardId(String cardId) {
		this.cardId = cardId;
	}

	public List getTitleCard() {
		return titleCard;
	}

	public void setTitleCard(List titleCard) {
		this.titleCard = titleCard;
	}

	public String getPersonalId() {
		return personalId;
	}

	public void setPersonalId(String personalId) {
		this.personalId = personalId;
	}

	public int getCollflag() {
		return collflag;
	}

	public void setCollflag(int collflag) {
		this.collflag = collflag;
	}

}
