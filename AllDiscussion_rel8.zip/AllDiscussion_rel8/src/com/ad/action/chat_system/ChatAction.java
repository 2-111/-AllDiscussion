package com.ad.action.chat_system;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.struts2.ServletActionContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ad.service.chat_system.ChatManager;
import com.ad.tools.Page;
import com.model.AllDiscussionChat;
import com.model.AllDiscussionUser;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class ChatAction extends ActionSupport {
	@Resource
	private ChatManager chatManager;
	private String cardId;
	private String context;
	private String vipId;
	private static int BUFFER_SIZE = 1024 * 1024;
	private String path;
	private File upload;
	private String uploadFileName;
	private String uploadContentType;
	private String savePath;
	@Resource
	private Page page;
	private List pageList;
	private List chat;
	private int currentPage;
	private static int ERVEY_PAGE = 2;
	private List title;
	private List chatPersonal;
	public String addChatObjectAction() {
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		AllDiscussionChat adC = new AllDiscussionChat();
		this.uploadImg();
		adC.setAllDiscussionVip(adu.getAllDiscussionVip());
		adC.setDeleteFlag(0);
		Timestamp d = new Timestamp(System.currentTimeMillis());
		adC.setTime(d);
		adC.setContext(context);
		adC.setImage(path);
		vipId=(String) session.get("chaVipId");
		chatManager.addChatObject(adu, vipId, adC);
		return "addChatObject_success";
	}

	public String getCardVip()
	{
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		session.put("chaVipId", vipId);
		return "getCardVip_success";
		
	}
	public void uploadImg() {
		try {

			if (upload != null) {
				InputStream in = new FileInputStream(getUpload());
				String imageFileName = new Date().getTime() + getExtention(uploadFileName);
				path = ServletActionContext.getServletContext().getRealPath(this.getSavePath()) + "/" + imageFileName;
				OutputStream out = new FileOutputStream(path);
				int count = 0;
				byte buffer[] = new byte[BUFFER_SIZE];
				while ((count = in.read(buffer)) > 0) {

					out.write(buffer, 0, count);

				}
				in.close();
				out.close();
				path = "image/" + imageFileName;
			} else {
				path = null;

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	private static String getExtention(String fileName) {
		int pos = fileName.lastIndexOf(".");
		return fileName.substring(pos);
	}


	public String showChat()
	{
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		vipId=(String) session.get("chaVipId");
		chat=chatManager.showChat(vipId);
		title=chatManager.getTitle(vipId);
		return "showChat_success";
	}
	
	public String showChatPersonal()
	{
		chatPersonal=chatManager.showPrivatePersonal(5);
		return "showChatPersonal_success";
	}
	
	
	public List getChatPersonal() {
		return chatPersonal;
	}

	public void setChatPersonal(List chatPersonal) {
		this.chatPersonal = chatPersonal;
	}

	public Page getPage() {
		return page;
	}

	public void setPage(Page page) {
		this.page = page;
	}

	public List getPageList() {
		return pageList;
	}

	public void setPageList(List pageList) {
		this.pageList = pageList;
	}

	public List getChat() {
		return chat;
	}

	public void setChat(List chat) {
		this.chat = chat;
	}

	public int getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}

	public List getTitle() {
		return title;
	}

	public void setTitle(List title) {
		this.title = title;
	}

	public String getCardId() {
		return cardId;
	}

	public void setCardId(String cardId) {
		this.cardId = cardId;
	}

	public String getContext() {
		return context;
	}

	public void setContext(String context) {
		this.context = context;
	}

	public String getVipId() {
		return vipId;
	}

	public void setVipId(String vipId) {
		this.vipId = vipId;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public File getUpload() {
		return upload;
	}

	public void setUpload(File upload) {
		this.upload = upload;
	}

	public String getUploadFileName() {
		return uploadFileName;
	}

	public void setUploadFileName(String uploadFileName) {
		this.uploadFileName = uploadFileName;
	}

	public String getUploadContentType() {
		return uploadContentType;
	}

	public void setUploadContentType(String uploadContentType) {
		this.uploadContentType = uploadContentType;
	}

	public String getSavePath() {
		return savePath;
	}

	public void setSavePath(String savePath) {
		this.savePath = savePath;
	}
	

}
