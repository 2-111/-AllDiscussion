package com.ad.action.login_system;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Timestamp;
import java.util.Date;

import javax.annotation.Resource;

import org.apache.struts2.ServletActionContext;

import com.ad.service.login_system.LoginManager;
import com.model.AllDiscussionHead;
import com.model.AllDiscussionUser;
import com.model.AllDiscussionVip;
import com.opensymphony.xwork2.ActionSupport;

public class LoginAction extends ActionSupport {
	@Resource
	private LoginManager loginManager;
	private String username;
	private String pwd;
	private String name;
	private String sex;
	private String email;
	private Long phoneNumber;
	private static int BUFFER_SIZE = 1024 * 1024;
	private String path;
	private File upload;
	private String uploadFileName;
	private String uploadContentType;
	private String savePath;
	public Long getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(Long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	public File getUpload() {
		return upload;
	}
	public void setUpload(File upload) {
		this.upload = upload;
	}
	public String getUploadFileName() {
		return uploadFileName;
	}
	public void setUploadFileName(String uploadFileName) {
		this.uploadFileName = uploadFileName;
	}
	public String getUploadContentType() {
		return uploadContentType;
	}
	public void setUploadContentType(String uploadContentType) {
		this.uploadContentType = uploadContentType;
	}
	public String getSavePath() {
		return savePath;
	}
	public void setSavePath(String savePath) {
		this.savePath = savePath;
	}
	public String login()
	{
		if(loginManager.loginUser(username, pwd))
		{
			
			return "login_success";
		}else
		{
			return "login_error";
			
		}
	}
	public String register()
	{
		AllDiscussionVip vip=new AllDiscussionVip();
		AllDiscussionUser user=new AllDiscussionUser();
		AllDiscussionHead head=new AllDiscussionHead();
		this.uploadImg();
		head.setNowhead(path);
		vip.setAllDiscussionHead(head);
		vip.setName(name);
		vip.setEmail(email);
		vip.setSex(sex);
		vip.setPrivate_(0);
		vip.setPhoneNumber(phoneNumber);
		vip.setDeletwFlag(0);
		user.setDeleteFlag(0);
		user.setPassWord(pwd);
		user.setUserName(username);
		Timestamp d = new Timestamp(System.currentTimeMillis()); 
		user.setNowTime(d);
		user.setUpdateTime(d);
		user.setAllDiscussionVip(vip);
		
		
		if(loginManager.registerUser(user))
		{
			
			return "register_success";
		}
		else
		{
			return "register_error";
		}
		
	}
	public void uploadImg() {
		try {

			if (upload != null) {
				InputStream in = new FileInputStream(getUpload());
				String imageFileName = new Date().getTime() + getExtention(uploadFileName);
				path = ServletActionContext.getServletContext().getRealPath(this.getSavePath()) + "/" + imageFileName;
				OutputStream out = new FileOutputStream(path);
				int count = 0;
				byte buffer[] = new byte[BUFFER_SIZE];
				while ((count = in.read(buffer)) > 0) {

					out.write(buffer, 0, count);

				}
				in.close();
				out.close();
				path = "image/" + imageFileName;
			} else {
				path = null;

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	private static String getExtention(String fileName) {
		int pos = fileName.lastIndexOf(".");
		return fileName.substring(pos);

	}
	
	
	
	
	

}
