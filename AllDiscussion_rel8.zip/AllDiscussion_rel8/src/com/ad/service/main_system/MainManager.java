package com.ad.service.main_system;

import java.util.List;
import java.util.Set;

import com.ad.dao.main_system.MainDAO;
import com.model.AllDiscussionChat;
import com.model.AllDiscussionCrads;
import com.model.AllDiscussionUser;
import com.model.AllDiscussionVip;

public interface MainManager {
	
	public List showConversation(int FirstResult,int MaxResults);
	public List showCard(int FirstResult,int MaxResults,String parentId);
	public boolean collectionCC(String cardId,AllDiscussionUser user);
	public boolean makePublicCon(AllDiscussionCrads card);
	public boolean makePublicCra_Remar(String cardId,AllDiscussionCrads card);
	public long getCountConversation();
	public long getCountCard(String cardId);
	public boolean addFriend(AllDiscussionUser myuser,String cardId,AllDiscussionChat adC);
	public boolean addHateObject(AllDiscussionUser myuser,String cardId);
	public boolean changegood(int goodFlag,String cardId);
	public boolean cancelCollection(String cardId,AllDiscussionUser user);
	public boolean deleteFriend(AllDiscussionUser myuser,AllDiscussionVip other);
	public List title(String cardId);
	public List showRemark(int FirstResult,int MaxResults,String parentId);
	public AllDiscussionVip personal(String cardId);
	public Set showCollection();
	public List showHate(AllDiscussionVip vip);
	public List showFriend();
	public List  isHate(AllDiscussionVip myVip,AllDiscussionVip vip);
	public List showRemarkRem(int FirstResult, int MaxResults, String parentId);
	public List isRecord(AllDiscussionVip myVip,String cardId);
	public void addRecord(AllDiscussionVip myVip,String cardId);
	public AllDiscussionCrads getCard(String cardId);
	public List allHate(AllDiscussionVip myVip, AllDiscussionVip vip);

}
