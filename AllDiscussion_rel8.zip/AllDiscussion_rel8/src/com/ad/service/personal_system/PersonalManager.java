package com.ad.service.personal_system;

import java.util.List;
import java.util.Set;

import com.model.AllDiscussionUser;
import com.model.AllDiscussionVip;

public interface PersonalManager {
	public AllDiscussionUser updateUser();
	public List showMyCards(int FirstResult, int MaxResults);
	public long getMyCount();
	public Set showAllCollection();
	public int getCountCollection();
	public List showCollection();
	public List cardTidings(int MaxResults);
	public long getCardTidings();
	public List showRecord(int MaxResults);
	public long getRecordCount();
	public void deleteHate(String vipId);
	public long getHateCount();
	public List showHate(int MaxResults);
	public int isSign();
	public int addSign();
	public void modifyPersonal(AllDiscussionUser adu);
	public List showAllCardTidings();
	public List showAllRecord();
	public List showAllHate();
	public List allChatPrivateTidings();
	public List chatPrivateTidings(int MaxResults);
}
