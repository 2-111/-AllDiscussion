package com.ad.action.personal_system;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import com.ad.service.personal_system.PersonalManager;
import com.ad.tools.Page;
import com.model.AllDiscussionUser;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class PersonalAction extends ActionSupport {
	@Resource
	private PersonalManager personalManager;
	@Resource
	private Page page;
	private int currentPage;
	private static int ERVEY_PAGE = 2;
	private List pageList;
	private List myCards;
	public String preShowPersonal()
	{
		currentPage = 1;
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		session.put("currentPage", currentPage);
		long totalCount = personalManager.getMyCount();
		page.setEveryPage(ERVEY_PAGE);
		page.setCurrentPage(currentPage);
		page.setTotalCount(totalCount);
		AllDiscussionUser adu=personalManager.updateUser();
		pageList = page.numberShow(page.getTotalPage(ERVEY_PAGE, totalCount), currentPage);
		myCards=personalManager.showMyCards(page.getBeginIndex(ERVEY_PAGE, currentPage),ERVEY_PAGE);
		return "preShowPersonal_success";
	}
	public String showPersonal()
	{
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		session.put("currentPage", currentPage);
		long totalCount = personalManager.getMyCount();
		page.setEveryPage(ERVEY_PAGE);
		page.setCurrentPage(currentPage);
		page.setTotalCount(totalCount);
		AllDiscussionUser adu=personalManager.updateUser();
		pageList = page.numberShow(page.getTotalPage(ERVEY_PAGE, totalCount), currentPage);
		myCards=personalManager.showMyCards(page.getBeginIndex(ERVEY_PAGE, currentPage),ERVEY_PAGE);
		return "showPersonal_success";
	}
	
	public int getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	public List getPageList() {
		return pageList;
	}
	public void setPageList(List pageList) {
		this.pageList = pageList;
	}
	public List getMyCards() {
		return myCards;
	}
	public void setMyCards(List myCards) {
		this.myCards = myCards;
	}
	
	


}
