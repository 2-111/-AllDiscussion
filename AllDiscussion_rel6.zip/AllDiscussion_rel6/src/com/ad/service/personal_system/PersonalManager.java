package com.ad.service.personal_system;

import java.util.List;

import com.model.AllDiscussionUser;

public interface PersonalManager {
	public AllDiscussionUser updateUser();
	public List showMyCards(int FirstResult, int MaxResults);
	public long getMyCount();
}
