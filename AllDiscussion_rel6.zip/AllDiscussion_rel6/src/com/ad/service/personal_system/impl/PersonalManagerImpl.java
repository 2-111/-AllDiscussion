package com.ad.service.personal_system.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ad.dao.personal_system.PersonalDAO;
import com.ad.service.personal_system.PersonalManager;
import com.model.AllDiscussionUser;
import com.opensymphony.xwork2.ActionContext;
@Transactional(rollbackFor = Exception.class)
public class PersonalManagerImpl implements PersonalManager {

	@Resource
	private PersonalDAO personalDao;
	
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public AllDiscussionUser updateUser()
	{
		
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu=(AllDiscussionUser) session.get("user");
		adu=(AllDiscussionUser) personalDao.get(AllDiscussionUser.class, adu.getUserId());
		return adu;
	}
	
	public List showMyCards(int FirstResult, int MaxResults)
	{
		
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu=(AllDiscussionUser) session.get("user");
		String hql="from AllDiscussionCrads adc where adc.allDiscussionVip.vipid='"+adu.getAllDiscussionVip().getVipid()+"'and adc.deleteFlag=0 order by adc.nowTime Desc";
		List list=personalDao.queryPageData(hql, FirstResult, MaxResults);
		return list;
		
	}
	public long getMyCount()
	{
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu=(AllDiscussionUser) session.get("user");
	    String hql="select count(*) from AllDiscussionCrads adc where adc.allDiscussionVip.vipid='"+adu.getAllDiscussionVip().getVipid()+"'and adc.deleteFlag=0";
		List list=personalDao.queryData(hql);
		long l = Long.valueOf(String.valueOf(list.get(0))).longValue();
		return l;
	}
	
	
}
