package com.ad.service.login_system;

import com.model.AllDiscussionUser;

public interface LoginManager {

	public boolean loginUser(String username,String pwd);
	public boolean registerUser(AllDiscussionUser user);
}
