package com.ad.service.login_system.impl;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ad.dao.login_system.LoginDAO;
import com.ad.service.login_system.LoginManager;
import com.model.AllDiscussionChat;
import com.model.AllDiscussionChatObject;
import com.model.AllDiscussionChatObjectId;
import com.model.AllDiscussionSign;
import com.model.AllDiscussionUser;
import com.opensymphony.xwork2.ActionContext;

@Transactional(rollbackFor = Exception.class)
public class LoginManagerImpl implements LoginManager {

	@Resource
	private LoginDAO loginDao;

	@Override
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public boolean loginUser(String username, String pwd) {
		// TODO Auto-generated method stub
		String hql = "from AllDiscussionUser adu where adu.userName='" + username + "' and adu.passWord='" + pwd + "'";
		List list = loginDao.queryData(hql);
		Map session = ActionContext.getContext().getSession();
		if (list.isEmpty()) {
			return false;
		} else {
			session.put("user", (AllDiscussionUser)list.get(0));
			return true;
		}

	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public boolean registerUser(AllDiscussionUser user) {
		// TODO Auto-generated method stub
		String hql = "from AllDiscussionUser adu where adu.userName='" + user.getUserName() + "'";
		System.out.println("why????????");
		List list = loginDao.queryData(hql);
		if (list.isEmpty()) {
			AllDiscussionSign ads=new AllDiscussionSign();
			AllDiscussionChatObject aco = new AllDiscussionChatObject();
			AllDiscussionChatObjectId acoid = new AllDiscussionChatObjectId();
			AllDiscussionChat adC = new AllDiscussionChat();
			adC.setDeleteFlag(0);
			adC.setParentId("0");
			ads.setCountNumber(0);
			Timestamp d = new Timestamp(System.currentTimeMillis()); 
			adC.setTime(d);
			ads.setLastTime(d);
			ads.setNowTime(d);
			user.getAllDiscussionVip().setAllDiscussionSign(ads);
			acoid.setAllDiscussionChat(adC);
			acoid.setAllDiscussionVip(user.getAllDiscussionVip());
			acoid.setAllDiscussionVip_1(user.getAllDiscussionVip());
			aco.setDeletFlag(0);
			aco.setIsFriends(0);
			aco.setStatusFriend(0);
			aco.setTidings(0);
			aco.setUpdateTime(d);
			aco.setId(acoid);
			loginDao.save(adC);
			loginDao.save(ads);
			loginDao.save(user.getAllDiscussionVip().getAllDiscussionHead());
			loginDao.save(user.getAllDiscussionVip());
			loginDao.save(user);
			loginDao.save(aco);
			return true;
		} else {
			return false;

		}
	}
	
	
	public boolean managerLogin(String managerId)
	{
		String hql="from AllDiscussionMananger adm where adm.managerId='"+managerId+"'";
		List list=loginDao.queryData(hql);
		Map session = ActionContext.getContext().getSession();
		
		if(list.isEmpty())
		{
			return false;
		}
		else
		{
			session.put("user", managerId);
			return true;
		}
	}
	

}
