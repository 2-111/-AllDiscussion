package com.ad.service.back_management.impl;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.hibernate.Session;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ad.dao.back_management.ManagementDAO;
import com.ad.dao.back_management.impl.ManagementDAOImpl;
import com.ad.service.back_management.BackManagement;
import com.model.AllDiscussionCrads;
import com.model.AllDiscussionUser;
import com.opensymphony.xwork2.ActionContext;

@Transactional(rollbackFor = Exception.class)
public class BackManagementImpl implements BackManagement {
	@Resource
	private ManagementDAO managementDao;

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public boolean deleteUser(String userId) {
		// TODO Auto-generated method stub
		try {
			String hql = "update allDiscussion_User set deleteFlag ='1' where userId='" + userId + "'";
			if (managementDao.deleteUser(hql)) {
				System.out.println("�û�ɾ���ɹ���");
			}
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
			return false;
		}

	}

	@Override
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public List selectAllUser() {
		// TODO Auto-generated method stu
		List users = managementDao.selectAllUser();
		return users;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public boolean addUser(AllDiscussionUser user) {
		// TODO Auto-generated method stub
		String hql = "from AllDiscussionUser adu where adu.userName='" + user.getUserName() + "'";
		List list = managementDao.queryData(hql);
		if (list.isEmpty()) {
			managementDao.save(user.getAllDiscussionVip().getAllDiscussionHead());
			managementDao.save(user.getAllDiscussionVip());
			managementDao.save(user);
		}
		return false;
	}

	@Transactional(propagation = Propagation.REQUIRED)
	public boolean modifyUser(String userId, String userName, String passWord) {
		try {
			String hql = "UPDATE allDiscussion_User SET userName='" + userName + "',passWord='" + passWord
					+ "' WHERE userId='" + userId + "'";
			if (managementDao.update(hql)) {
				System.out.println("�û���Ϣ�޸ĳɹ���");
			}
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
			return false;
		}

	}

	@Override
	public List selectAllCards() {
		// TODO Auto-generated method stub
		try {
			// String sql = "select new
			// com.model.AllDiscussionCrads(cardsId,context,goods,title,relyN,updateTime)
			// from AllDiscussionCrads";
			// String sql = "select
			// cardsId,context,goods,title,relyN,nowTime,updateTime from
			// AllDiscussionCrads";
			// String sql = "from AllDiscussionCrads a";
			String sql = "from AllDiscussionCrads where deleteFlag='0'";
			List list = managementDao.selectAllCards(sql);
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
			return null;
		}
	}

	@Override
	public boolean deleteCards(String cardsId) {
		try {
			String hql = "update allDiscussion_Crads set deleteFlag ='1' where cardsId='" + cardsId + "'";
			if (managementDao.deleteCards(hql)) {
				System.out.println("����ɾ���ɹ���");
			}
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
			return false;
		}

	}

	@Override
	public List selectAllConversation() {
		// TODO Auto-generated method stu
		// TODO Auto-generated method stub
		try {
			String sql = "from AllDiscussionConversation where deleteFlag='0'";
			List list = managementDao.selectAllCards(sql);
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
			return null;
		}

	}

	@Override
	public boolean deleteConversation(String conversationId) {
		try {
			String hql = "update allDiscussion_Conversation set deleteFlag ='1' where conversationId='" + conversationId
					+ "'";
			if (managementDao.deleteConversation(hql)) {
				System.out.println("����ɾ���ɹ���");
			}
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
			return false;
		}

	}

}
