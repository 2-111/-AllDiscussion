package com.ad.action.personal_system;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.struts2.ServletActionContext;

import com.ad.service.personal_system.PersonalManager;
import com.ad.tools.Page;
import com.model.AllDiscussionHead;
import com.model.AllDiscussionUser;
import com.model.AllDiscussionVip;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class PersonalAction extends ActionSupport {
	@Resource
	private PersonalManager personalManager;
	@Resource
	private Page page;
	private int currentPage;
	private static int ERVEY_PAGE = 7;
	private List pageList;
	private List myCards;
	private List collectCards;
	private int collectionCount;
	private Set allAollectionCards;
	private List cardTidings;
	private long tidingsCount;
	private List cardRecord;
	private long recordCount;
	private List hatePersonal;
	private long hateCount;
	private String vipId;
	private int isSgin;
	private int sginFlag;
	private static int BUFFER_SIZE = 1024 * 1024;
	private String name;
	private String sex;
	private String email;
	private Long phoneNumber;
	private String path;
	private File upload;
	private String uploadFileName;
	private String uploadContentType;
	private String savePath;
	private List allTidings;
	private List allRecord;
	private List allHate;
	private List chatTidings;
	private List allChatTidings;
	private long friendTidingsCount;
	private List friendTidings;
	private List allFriendTidings;
	private long chatTidingsCount;
	private int hateEmtry;
	private List hateAll;
	public String preShowPersonal()
	{
		currentPage = 1;
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		session.put("currentPage", currentPage);
		long totalCount = personalManager.getMyCount();
		page.setEveryPage(ERVEY_PAGE);
		page.setCurrentPage(currentPage);
		page.setTotalCount(totalCount);
		AllDiscussionUser adu=personalManager.updateUser();
		pageList = page.numberShow(page.getTotalPage(ERVEY_PAGE, totalCount), currentPage);
		myCards=personalManager.showMyCards(page.getBeginIndex(ERVEY_PAGE, currentPage),ERVEY_PAGE);
		collectCards=personalManager.showCollection();
		collectionCount=personalManager.getCountCollection();
		cardTidings=personalManager.cardTidings(5);
		tidingsCount=personalManager.getCardTidings();
		cardRecord=personalManager.showRecord(5);
		recordCount=personalManager.getRecordCount();
		hatePersonal=personalManager.showHate(5);
		hateAll=personalManager.showAllHate();
		if(hateAll.isEmpty())
		{
			hateEmtry=1;
		}else
		{
			hateEmtry=0;
			
		}
		hateCount=personalManager.getHateCount();
		isSgin=personalManager.isSign();
		chatTidings=personalManager.chatPrivateTidings(5);
		chatTidingsCount=personalManager.getChatTidingsCount();
		friendTidings=personalManager.showFriendTidings(5);
		friendTidingsCount=personalManager.getCountFriendTidings();
		return "preShowPersonal_success";
	}
	public String showPersonal()
	{
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		session.put("currentPage", currentPage);
		long totalCount = personalManager.getMyCount();
		page.setEveryPage(ERVEY_PAGE);
		page.setCurrentPage(currentPage);
		page.setTotalCount(totalCount);
		AllDiscussionUser adu=personalManager.updateUser();
		pageList = page.numberShow(page.getTotalPage(ERVEY_PAGE, totalCount), currentPage);
		myCards=personalManager.showMyCards(page.getBeginIndex(ERVEY_PAGE, currentPage),ERVEY_PAGE);
		collectCards=personalManager.showCollection();
		collectionCount=personalManager.getCountCollection();
		cardTidings=personalManager.cardTidings(5);
		tidingsCount=personalManager.getCardTidings();
		cardRecord=personalManager.showRecord(5);
		recordCount=personalManager.getRecordCount();
		hatePersonal=personalManager.showHate(5);
		hateCount=personalManager.getHateCount();
		isSgin=personalManager.isSign();
		chatTidings=personalManager.chatPrivateTidings(5);
		chatTidingsCount=personalManager.getChatTidingsCount();
		friendTidings=personalManager.showFriendTidings(5);
		friendTidingsCount=personalManager.getCountFriendTidings();
		hateAll=personalManager.showAllHate();
		if(hateAll.isEmpty())
		{
			hateEmtry=1;
		}else
		{
			hateEmtry=0;
			
		}
		return "showPersonal_success";
	}
	public String showAllCollection()
	{
		allAollectionCards=personalManager.showAllCollection();
		return "showAllCollection_success";
	}
	public String showAllCardTidings()
	{
		allTidings=personalManager.showAllCardTidings();
		return "showAllCardTidings_success";
	}
	
	public String showAllRecord()
	{
		allRecord=personalManager.showAllRecord();
		return "showAllRecord_success";
	}
	public String showAllHate()
	{
		allHate=personalManager.showAllHate();
		return "showAllHate_success";
	}
	
	public String deleteHate()
	{
		personalManager.deleteHate(vipId);
		return "deleteHate_success";
	}
	public String addSgin()
	{
		sginFlag=personalManager.addSign();
		return "addSgin_success";
	}
	public String modifyPersonal()
	{
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		AllDiscussionVip vip=adu.getAllDiscussionVip();
		AllDiscussionHead head=vip.getAllDiscussionHead();
		this.uploadImg();
		head.setNowhead(path);
		vip.setAllDiscussionHead(head);
		vip.setName(name);
		vip.setEmail(email);
		vip.setSex(sex);
		vip.setPrivate_(0);
		vip.setPhoneNumber(phoneNumber);
		vip.setDeletwFlag(0);
		adu.setAllDiscussionVip(vip);
		personalManager.modifyPersonal(adu);
		upload=null;
		return "modifyPersonal_success";
	}
	
	public void uploadImg() {
		try {

			if (upload != null) {
				InputStream in = new FileInputStream(getUpload());
				String imageFileName = new Date().getTime() + getExtention(uploadFileName);
				path = ServletActionContext.getServletContext().getRealPath(this.getSavePath()) + "/" + imageFileName;
				OutputStream out = new FileOutputStream(path);
				int count = 0;
				byte buffer[] = new byte[BUFFER_SIZE];
				while ((count = in.read(buffer)) > 0) {

					out.write(buffer, 0, count);

				}
				in.close();
				out.close();
				path = "image/" + imageFileName;
			} else {
				path = null;

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	private static String getExtention(String fileName) {
		int pos = fileName.lastIndexOf(".");
		return fileName.substring(pos);

	}
	
	
	public int getHateEmtry() {
		return hateEmtry;
	}
	public void setHateEmtry(int hateEmtry) {
		this.hateEmtry = hateEmtry;
	}
	public List getHateAll() {
		return hateAll;
	}
	public void setHateAll(List hateAll) {
		this.hateAll = hateAll;
	}
	public long getFriendTidingsCount() {
		return friendTidingsCount;
	}
	public void setFriendTidingsCount(long friendTidingsCount) {
		this.friendTidingsCount = friendTidingsCount;
	}
	public List getFriendTidings() {
		return friendTidings;
	}
	public void setFriendTidings(List friendTidings) {
		this.friendTidings = friendTidings;
	}
	public List getAllFriendTidings() {
		return allFriendTidings;
	}
	public void setAllFriendTidings(List allFriendTidings) {
		this.allFriendTidings = allFriendTidings;
	}
	public long getChatTidingsCount() {
		return chatTidingsCount;
	}
	public void setChatTidingsCount(long chatTidingsCount) {
		this.chatTidingsCount = chatTidingsCount;
	}
	public List getChatTidings() {
		return chatTidings;
	}
	public void setChatTidings(List chatTidings) {
		this.chatTidings = chatTidings;
	}
	public List getAllChatTidings() {
		return allChatTidings;
	}
	public void setAllChatTidings(List allChatTidings) {
		this.allChatTidings = allChatTidings;
	}
	public List getAllTidings() {
		return allTidings;
	}
	public void setAllTidings(List allTidings) {
		this.allTidings = allTidings;
	}
	public List getAllRecord() {
		return allRecord;
	}
	public void setAllRecord(List allRecord) {
		this.allRecord = allRecord;
	}
	public List getAllHate() {
		return allHate;
	}
	public void setAllHate(List allHate) {
		this.allHate = allHate;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Long getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(Long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	public File getUpload() {
		return upload;
	}
	public void setUpload(File upload) {
		this.upload = upload;
	}
	public String getUploadFileName() {
		return uploadFileName;
	}
	public void setUploadFileName(String uploadFileName) {
		this.uploadFileName = uploadFileName;
	}
	public String getUploadContentType() {
		return uploadContentType;
	}
	public void setUploadContentType(String uploadContentType) {
		this.uploadContentType = uploadContentType;
	}
	public String getSavePath() {
		return savePath;
	}
	public void setSavePath(String savePath) {
		this.savePath = savePath;
	}
	public int getSginFlag() {
		return sginFlag;
	}
	public void setSginFlag(int sginFlag) {
		this.sginFlag = sginFlag;
	}
	public int getIsSgin() {
		return isSgin;
	}
	public void setIsSgin(int isSgin) {
		this.isSgin = isSgin;
	}
	public List getHatePersonal() {
		return hatePersonal;
	}
	public void setHatePersonal(List hatePersonal) {
		this.hatePersonal = hatePersonal;
	}
	public long getHateCount() {
		return hateCount;
	}
	public void setHateCount(long hateCount) {
		this.hateCount = hateCount;
	}
	public String getVipId() {
		return vipId;
	}
	public void setVipId(String vipId) {
		this.vipId = vipId;
	}
	public List getCardRecord() {
		return cardRecord;
	}
	public void setCardRecord(List cardRecord) {
		this.cardRecord = cardRecord;
	}
	public long getRecordCount() {
		return recordCount;
	}
	public void setRecordCount(long recordCount) {
		this.recordCount = recordCount;
	}
	public List getCardTidings() {
		return cardTidings;
	}
	public void setCardTidings(List cardTidings) {
		this.cardTidings = cardTidings;
	}
	public long getTidingsCount() {
		return tidingsCount;
	}
	public void setTidingsCount(long tidingsCount) {
		this.tidingsCount = tidingsCount;
	}
	public Set getAllAollectionCards() {
		return allAollectionCards;
	}
	public void setAllAollectionCards(Set allAollectionCards) {
		this.allAollectionCards = allAollectionCards;
	}
	public List getCollectCards() {
		return collectCards;
	}
	public void setCollectCards(List collectCards) {
		this.collectCards = collectCards;
	}
	public int getCollectionCount() {
		return collectionCount;
	}
	public void setCollectionCount(int collectionCount) {
		this.collectionCount = collectionCount;
	}
	public int getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	public List getPageList() {
		return pageList;
	}
	public void setPageList(List pageList) {
		this.pageList = pageList;
	}
	public List getMyCards() {
		return myCards;
	}
	public void setMyCards(List myCards) {
		this.myCards = myCards;
	}
	
	


}
