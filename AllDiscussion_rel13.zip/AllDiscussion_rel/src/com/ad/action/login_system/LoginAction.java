package com.ad.action.login_system;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.struts2.ServletActionContext;

import com.ad.service.login_system.LoginManager;
import com.model.AllDiscussionConversation;
import com.model.AllDiscussionHead;
import com.model.AllDiscussionUser;
import com.model.AllDiscussionVip;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class LoginAction extends ActionSupport {
	@Resource
	private LoginManager loginManager;
	private String username;
	private String pwd;
	private String name;
	private String sex;
	private String email;
	private Long phoneNumber;
	private static int BUFFER_SIZE = 1024 * 1024;
	private String path;
	private File upload;
	private String uploadFileName;
	private String uploadContentType;
	private String savePath;
	private String managerId;
	
	public String getManagerId() {
		return managerId;
	}
	public void setManagerId(String managerId) {
		this.managerId = managerId;
	}
	public Long getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(Long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	public File getUpload() {
		return upload;
	}
	public void setUpload(File upload) {
		this.upload = upload;
	}
	public String getUploadFileName() {
		return uploadFileName;
	}
	public void setUploadFileName(String uploadFileName) {
		this.uploadFileName = uploadFileName;
	}
	public String getUploadContentType() {
		return uploadContentType;
	}
	public void setUploadContentType(String uploadContentType) {
		this.uploadContentType = uploadContentType;
	}
	public String getSavePath() {
		return savePath;
	}
	public void setSavePath(String savePath) {
		this.savePath = savePath;
	}
	public String login()
	{
		if(loginManager.loginUser(username, pwd))
		{
			username=null; pwd=null;
			return "login_success";
		}else
		{
			username=null; pwd=null;
			return "login_error";
			
		}
	}
	public String register()
	{
		System.out.println("what??????");
		AllDiscussionVip vip=new AllDiscussionVip();
		AllDiscussionUser user=new AllDiscussionUser();
		AllDiscussionHead head=new AllDiscussionHead();
		this.uploadImg();
		head.setNowhead(path);
		vip.setAllDiscussionHead(head);
		vip.setName(name);
		vip.setEmail(email);
		vip.setSex(sex);
		vip.setPrivate_(0);
		vip.setPhoneNumber(phoneNumber);
		vip.setDeletwFlag(0);
		user.setDeleteFlag(0);
		user.setPassWord(pwd);
		user.setUserName(username);
		Timestamp d = new Timestamp(System.currentTimeMillis()); 
		user.setNowTime(d);
		user.setUpdateTime(d);
		user.setAllDiscussionVip(vip);
		
		
		if(loginManager.registerUser(user))
		{
			
			username=null;
			pwd=null;
			email=null;
			phoneNumber=null;
			name=null;
			upload=null;
			uploadFileName=null;
			path=null;
			savePath=null;
			uploadContentType=null;
			return "register_success";
		}
		else
		{
			username=null;
			pwd=null;
			email=null;
			phoneNumber=null;
			name=null;
			upload=null;
			uploadFileName=null;
			path=null;
			savePath=null;
			uploadContentType=null;
			return "register_error";
		}
	
		
	}
	
	
	public void uploadImg() {
		try {

			if (upload != null) {
				InputStream in = new FileInputStream(getUpload());
				String imageFileName = new Date().getTime() + getExtention(uploadFileName);
				path = ServletActionContext.getServletContext().getRealPath(this.getSavePath()) + "/" + imageFileName;
				OutputStream out = new FileOutputStream(path);
				int count = 0;
				byte buffer[] = new byte[BUFFER_SIZE];
				while ((count = in.read(buffer)) > 0) {

					out.write(buffer, 0, count);

				}
				in.close();
				out.close();
				path = "image/" + imageFileName;
			} else {
				path = null;

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	private static String getExtention(String fileName) {
		int pos = fileName.lastIndexOf(".");
		return fileName.substring(pos);

	}
	
	
	public String outLogin()
	{
		AllDiscussionConversation adc = new AllDiscussionConversation();
		Map session = ActionContext.getContext().getSession();
		session.put("user",null);
		return "outLogin_success";
	}
	
	public String managerLogin()
	{
		if(loginManager.managerLogin(managerId))
		{
			return "managerLogin_success";
		}
		else
		{
			return "managerLogin_error";
			
		}
		
	}
	

}
