package com.ad.action.back_management;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import com.ad.service.back_management.BackManagement;
import com.ad.service.back_management.impl.BackManagementImpl;
import com.model.AllDiscussionHead;
import com.model.AllDiscussionMananger;
import com.model.AllDiscussionUser;
import com.model.AllDiscussionCrads;
import com.model.AllDiscussionConversation;
import com.model.AllDiscussionVip;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class BackManagementAction extends ActionSupport {
	@Resource
	private BackManagement backManagement;
	private String userId;
	private AllDiscussionMananger allDiscussionMananger;
	private AllDiscussionVip allDiscussionVip;
	private String userName;
	private String passWord;
	private Integer deleteFlag;
	private String operater;
	private Timestamp nowTime;
	private Timestamp updateTime;
	private List AllDiscussionUsers;
	private List AllDiscussionCrads;
	private List AllDiscussionConversation;
	private String context;
	private String title;
	private Integer relyN;
	private Integer goods;
	private String cardsId;
	private String conversationId;

	public List getAllDiscussionConversation() {
		return AllDiscussionConversation;
	}

	public void setAllDiscussionConversation(List allDiscussionConversation) {
		AllDiscussionConversation = allDiscussionConversation;
	}

	public String getConversationId() {
		return conversationId;
	}

	public void setConversationId(String conversationId) {
		this.conversationId = conversationId;
	}

	public BackManagement getBackManagement() {
		return backManagement;
	}

	public void setBackManagement(BackManagement backManagement) {
		this.backManagement = backManagement;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public AllDiscussionMananger getAllDiscussionMananger() {
		return allDiscussionMananger;
	}

	public void setAllDiscussionMananger(AllDiscussionMananger allDiscussionMananger) {
		this.allDiscussionMananger = allDiscussionMananger;
	}

	public AllDiscussionVip getAllDiscussionVip() {
		return allDiscussionVip;
	}

	public void setAllDiscussionVip(AllDiscussionVip allDiscussionVip) {
		this.allDiscussionVip = allDiscussionVip;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassWord() {
		return passWord;
	}

	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}

	public Integer getDeleteFlag() {
		return deleteFlag;
	}

	public void setDeleteFlag(Integer deleteFlag) {
		this.deleteFlag = deleteFlag;
	}

	public String getOperater() {
		return operater;
	}

	public void setOperater(String operater) {
		this.operater = operater;
	}

	public Timestamp getNowTime() {
		return nowTime;
	}

	public void setNowTime(Timestamp nowTime) {
		this.nowTime = nowTime;
	}

	public Timestamp getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Timestamp updateTime) {
		this.updateTime = updateTime;
	}

	public List getAllDiscussionUsers() {
		return AllDiscussionUsers;
	}

	public void setAllDiscussionUsers(List allDiscussionUsers) {
		AllDiscussionUsers = allDiscussionUsers;
	}

	public List getAllDiscussionCrads() {
		return AllDiscussionCrads;
	}

	public void setAllDiscussionCrads(List allDiscussionCrads) {
		AllDiscussionCrads = allDiscussionCrads;
	}

	public String getContext() {
		return context;
	}

	public void setContext(String context) {
		this.context = context;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Integer getRelyN() {
		return relyN;
	}

	public void setRelyN(Integer relyN) {
		this.relyN = relyN;
	}

	public Integer getGoods() {
		return goods;
	}

	public void setGoods(Integer goods) {
		this.goods = goods;
	}

	public String getCardsId() {
		return cardsId;
	}

	public void setCardsId(String cardsId) {
		this.cardsId = cardsId;
	}

	public String selectAllUser() {
		AllDiscussionUsers = backManagement.selectAllUser();
		ActionContext.getContext().put("AllDiscussionUsers", AllDiscussionUsers);
		return "ShowAllUser";

	}

	public String deleteUser() {
		backManagement.deleteUser(userId);
		return this.selectAllUser();
	}

	public String modifyUser() {
		backManagement.modifyUser(userId, userName, passWord);
		return this.selectAllUser();
	}

	public String selectAllCards() {
		AllDiscussionCrads = backManagement.selectAllCards();
		ActionContext.getContext().put("AllDiscussionCrads", AllDiscussionCrads);
		return "ShowAllCards";
	}

	public String deleteCards() {
		backManagement.deleteCards(cardsId);
		return this.selectAllCards();
	}

	public String selectAllConversation() {
		AllDiscussionConversation = backManagement.selectAllConversation();
		ActionContext.getContext().put("AllDiscussionConversation", AllDiscussionConversation);
		return "ShowAllConversation";
	}

	public String deleteConversation() {
		backManagement.deleteConversation(conversationId);
		return this.selectAllConversation();
	}

}
