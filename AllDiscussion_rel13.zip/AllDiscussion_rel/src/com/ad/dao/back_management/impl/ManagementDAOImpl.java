package com.ad.dao.back_management.impl;

import java.io.Serializable;
import java.util.List;

import javax.annotation.Resource;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import com.ad.dao.back_management.ManagementDAO;

public class ManagementDAOImpl implements ManagementDAO {
	@Resource
	private SessionFactory sessionFactory;

	@Override
	public boolean save(Object obj) {
		try {
			Session session = sessionFactory.getCurrentSession();
			session.save(obj);
		} catch (Exception e) {
			e.printStackTrace();
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			return false;
		}

		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List queryData(String hql) {
		// TODO Auto-generated method stu
		try {
			Session session = sessionFactory.getCurrentSession();
			Query q = session.createQuery(hql);
			List list = q.list();
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			return null;
		}
	}

	@Override
	public boolean deleteUser(String sql) {
		Session session = sessionFactory.getCurrentSession();
		int i = session.createSQLQuery(sql).executeUpdate();
		if (i != 0) {
			System.out.println(i);
			session.flush();
			return true;
		} else {
			return false;
		}

	}

	@Override
	public List selectAllUser() {
		// TODO Auto-generated method stub
		try {
			Session session = sessionFactory.getCurrentSession();
			Query q = session.createQuery("from AllDiscussionUser a where deleteFlag='0'");
			List list = q.list();
			System.out.println(list);
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	@Override
	public boolean update(String Sql) {
		// TODO Auto-generated method stub
		try {
			Session session = sessionFactory.getCurrentSession();
			session.createSQLQuery(Sql).executeUpdate();
			return true;
		} catch (Exception e) {

			e.printStackTrace();
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			return false;
		}
	}

	@Override
	public List selectAllCards(String sql) {
		try {
			Session session = sessionFactory.getCurrentSession();
			Query q = session.createQuery(sql);
			List list = q.list();
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public boolean deleteCards(String sql) {
		// TODO Auto-generated method stubSession session =
		// sessionFactory.getCurrentSession();
		Session session = sessionFactory.getCurrentSession();
		int i = session.createSQLQuery(sql).executeUpdate();
		if (i != 0) {
			System.out.println(i);
			session.flush();
			return true;
		} else {
			return false;
		}
	}

	@Override
	public List selectAllConversation(String sql) {
		// TODO Auto-generated method stub
		try {
			Session session = sessionFactory.getCurrentSession();
			Query q = session.createQuery(sql);
			List list = q.list();
			System.out.println(list);
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public boolean deleteConversation(String sql) {
		// TODO Auto-generated method stub
		Session session = sessionFactory.getCurrentSession();
		int i = session.createSQLQuery(sql).executeUpdate();
		if (i != 0) {
			session.flush();
			return true;
		} else {
			return false;
		}
	}

}
