package com.ad.service.main_system.impl;

import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ad.dao.main_system.MainDAO;
import com.ad.service.main_system.MainManager;
import com.model.AllDiscussionChat;
import com.model.AllDiscussionChatObject;
import com.model.AllDiscussionChatObjectId;
import com.model.AllDiscussionConversation;
import com.model.AllDiscussionCrads;
import com.model.AllDiscussionHate;
import com.model.AllDiscussionHateId;
import com.model.AllDiscussionRecrod;
import com.model.AllDiscussionRecrodId;
import com.model.AllDiscussionUser;
import com.model.AllDiscussionVip;
import com.opensymphony.xwork2.ActionContext;

@Transactional(rollbackFor = Exception.class)
public class MainManagerImpl implements MainManager {
	@Resource
	private MainDAO mainDao;

	@Override
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public List showConversation(int FirstResult, int MaxResults) {
		// TODO Auto-generated method stub
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		// String hql = "from AllDiscussionCrads adc where adc.parentId='0' and
		// deleteFlag='0' order by adc.allDiscussionConversation.hot Desc";
		String hql1 = "from AllDiscussionCrads adc where adc.parentId='0' and deleteFlag='0' and adc.allDiscussionVip not in(select ah.id.allDiscussionVip_1 from AllDiscussionHate ah where ah.id.allDiscussionVip.vipid='"
				+ adu.getAllDiscussionVip().getVipid() + "' and ah.deleteFlag=0)"
				+ "order by adc.allDiscussionConversation.hot Desc";
		List info = mainDao.queryPageData(hql1, FirstResult, MaxResults);
		return info;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public List showCard(int FirstResult, int MaxResults, String parentId) {
		// TODO Auto-generated method stub
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		String hql = "from AllDiscussionCrads adc where adc.deleteFlag='0' and adc.parentId='" + parentId
				+ "' and adc.allDiscussionVip not in(select ah.id.allDiscussionVip_1 from AllDiscussionHate ah where ah.id.allDiscussionVip.vipid='"
				+ adu.getAllDiscussionVip().getVipid() + "' and ah.deleteFlag=0) order by adc.updateTime Desc";
		List info = mainDao.queryPageData(hql, FirstResult, MaxResults);
		List listRecord = this.isRecord(adu.getAllDiscussionVip(), parentId);
		if (listRecord.isEmpty()) {
			this.addRecord(adu.getAllDiscussionVip(), parentId);
		} else {
			AllDiscussionRecrod adr = (AllDiscussionRecrod) listRecord.get(0);
			Timestamp d = new Timestamp(System.currentTimeMillis());
			adr.setTime(d);
			mainDao.update(adr);
		}
		
		return info;
	}

	public List isRecord(AllDiscussionVip myVip, String cardId) {
		String hql = "from AllDiscussionRecrod adr where adr.id.allDiscussionCrads.cardsId='" + cardId
				+ "' and adr.id.allDiscussionVip.vipid='" + myVip.getVipid() + "'";
		List list = mainDao.queryData(hql);
		return list;

	}

	public void addRecord(AllDiscussionVip myVip, String cardId) {
		AllDiscussionRecrod adr = new AllDiscussionRecrod();
		Timestamp d = new Timestamp(System.currentTimeMillis());
		adr.setTime(d);
		AllDiscussionRecrodId adri = new AllDiscussionRecrodId();
		System.out.println(cardId);
		AllDiscussionCrads card = (AllDiscussionCrads) mainDao.get(AllDiscussionCrads.class, cardId);
		adri.setAllDiscussionCrads(card);
		adri.setAllDiscussionVip(myVip);
		adr.setId(adri);
		mainDao.save(adr);
	}

	@Transactional(propagation = Propagation.REQUIRED)
	public List title(String cardId) {
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		String hql = "from AllDiscussionCrads adc where adc.cardsId='" + cardId + "'";
		List list = mainDao.queryData(hql);
		AllDiscussionCrads adc=(AllDiscussionCrads) list.get(0);
		if(adc.getAllDiscussionVip().getVipid().equals(adu.getAllDiscussionVip().getVipid()))
		{
			adc.setTidings(0);
			mainDao.update(adc);
		}
		return list;
	}

	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public List showRemark(int FirstResult, int MaxResults, String parentId) {
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		String hql = "from AllDiscussionCrads adc where adc.deleteFlag='0' and adc.parentId='" + parentId
				+ "' and adc.allDiscussionVip not in(select ah.id.allDiscussionVip_1 from AllDiscussionHate ah where ah.id.allDiscussionVip.vipid='"
				+ adu.getAllDiscussionVip().getVipid() + "' and ah.deleteFlag=0) order by adc.nowTime";
		List info = mainDao.queryPageData(hql, FirstResult, MaxResults);
		List listRecord = this.isRecord(adu.getAllDiscussionVip(), parentId);
		if (listRecord.isEmpty()) {
			this.addRecord(adu.getAllDiscussionVip(), parentId);
		} else {
			AllDiscussionRecrod adr = (AllDiscussionRecrod) listRecord.get(0);
			Timestamp d = new Timestamp(System.currentTimeMillis());
			adr.setTime(d);
			mainDao.update(adr);
		}
		return info;
	}

	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public List showRemarkRem(int FirstResult, int MaxResults, String parentId) {
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		String hql = "from AllDiscussionCrads adc where adc.deleteFlag='0' and adc.parentId='" + parentId
				+ "' and adc.allDiscussionVip not in(select ah.id.allDiscussionVip_1 from AllDiscussionHate ah where ah.id.allDiscussionVip.vipid='"
				+ adu.getAllDiscussionVip().getVipid() + "' and ah.deleteFlag=0) order by adc.nowTime";
		List info = mainDao.queryPageData(hql, FirstResult, MaxResults);
		return info;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public boolean collectionCC(String cardId, AllDiscussionUser user) {
		// TODO Auto-generated method stub
		AllDiscussionVip vip = user.getAllDiscussionVip();
		String hql = "from AllDiscussionCrads adc where adc.cardsId='" + cardId + "'";
		List list = mainDao.queryData(hql);
		AllDiscussionCrads card = (AllDiscussionCrads) list.get(0);
		List isCollect=this.isCollection(vip, cardId);
		if(isCollect.isEmpty())
		{
		vip.getAllDiscussionCradses_1().add(card);
		card.getAllDiscussionVips().add(vip);
		mainDao.clear();
		mainDao.update(card);
		mainDao.clear();
		mainDao.update(vip);
		return true;
		}
		else
		{
			return true;
		}
	}

	@Transactional(propagation = Propagation.REQUIRED)
	public boolean cancelCollection(String cardId, AllDiscussionUser user) {
		AllDiscussionVip vip = user.getAllDiscussionVip();
		AllDiscussionCrads card = (AllDiscussionCrads) mainDao.get(AllDiscussionCrads.class, cardId);
		List isCollect=this.isCollection(vip, cardId);
		if(isCollect.isEmpty())
		{
			
			return true;
		}
		else
		{
		String sql = "delete from allDiscussion_Collection where VIPId='" + user.getAllDiscussionVip().getVipid()
				+ "' and cardsId='" + cardId + "'";
		mainDao.sqlDelete(sql);
		return true;
		}
	}
	public List isCollection(AllDiscussionVip vip,String cardId)
	{
		String sql="select * from allDiscussion_Collection where VIPId='"+vip.getVipid()+"' and cardsId='"+cardId+"'";
		List list=mainDao.querySql(sql);
		return list;
		
	}
	

	@Override
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public boolean makePublicCon(AllDiscussionCrads card) {
		// TODO Auto-generated method stub
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		mainDao.save(card.getAllDiscussionConversation());
		mainDao.save(card);

		return true;

	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public boolean makePublicCra_Remar(String cardId, AllDiscussionCrads mycard) {
		// TODO Auto-generated method stub
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		String hql = "from AllDiscussionCrads adc where adc.cardsId='" + cardId + "'";
		List list = mainDao.queryData(hql);
		AllDiscussionCrads card = (AllDiscussionCrads) list.get(0);
		
		if (this.isHate(adu.getAllDiscussionVip(), card.getAllDiscussionVip()).isEmpty()) {
			int i = card.getRelyN();
			i = i + 1;
			card.setRelyN(i);
			mycard.setAllDiscussionConversation(card.getAllDiscussionConversation());
			int hot = card.getAllDiscussionConversation().getHot();
			hot = hot + 100;
			card.getAllDiscussionConversation().setHot(hot);
			Timestamp d = new Timestamp(System.currentTimeMillis());
			card.setUpdateTime(d);
			int j=card.getTidings();
			j=j+1;
			card.setTidings(j);
			mainDao.update(card.getAllDiscussionConversation());
			mainDao.update(card);
			mainDao.save(mycard);
			return true;
		} else {
			return false;

		}
	}

	@Override
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public long getCountConversation() {
		// TODO Auto-generated method stub
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		String hql = "select count(*) from AllDiscussionCrads adc where adc.deleteFlag='0' and adc.parentId='0'"
				+ " and adc.allDiscussionVip not in(select ah.id.allDiscussionVip_1 from AllDiscussionHate ah where ah.id.allDiscussionVip.vipid='"
				+ adu.getAllDiscussionVip().getVipid() + "' and ah.deleteFlag=0)";
		List list = mainDao.queryData(hql);
		long l = Long.valueOf(String.valueOf(list.get(0))).longValue();
		return l;
	}

	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public long getCountCard(String cardId) {
		// TODO Auto-generated method stub
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		String hql = "select count(*) from AllDiscussionCrads adc where adc.deleteFlag='0' and adc.parentId='" + cardId
				+ "' and adc.allDiscussionVip not in(select ah.id.allDiscussionVip_1 from AllDiscussionHate ah where ah.id.allDiscussionVip.vipid='"
				+ adu.getAllDiscussionVip().getVipid() + "' and ah.deleteFlag=0)";
		List list = mainDao.queryData(hql);
		long l = Long.valueOf(String.valueOf(list.get(0))).longValue();
		return l;
	}

	

	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public List showFriend() {
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		String hql = "from AllDiscussionChatObject aco where aco.id.allDiscussionVip.vipid='"
				+ adu.getAllDiscussionVip().getVipid() + "' and aco.isFriends=0 and aco.deletFlag=0 ";
		List friendList = mainDao.queryData(hql);
		return friendList;
	}


	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public Set showCollection() {
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		AllDiscussionVip advNew = (AllDiscussionVip) mainDao.get(AllDiscussionVip.class,
				adu.getAllDiscussionVip().getVipid());
		Set setList = advNew.getAllDiscussionCradses_1();
		return setList;

	}

	public boolean deleteFriend(AllDiscussionUser myuser, AllDiscussionVip other) {
		// TODO Auto-generated method stub

		return false;
	}


	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public boolean addHateObject(AllDiscussionUser myuser, String cardId) {
		// TODO Auto-generated method stub
		AllDiscussionCrads card = (AllDiscussionCrads) mainDao.get(AllDiscussionCrads.class, cardId);
		AllDiscussionVip other = card.getAllDiscussionVip();
		List list=this.allHate(myuser.getAllDiscussionVip(), other);
		if(list.isEmpty())
		{
		AllDiscussionHateId ahi = new AllDiscussionHateId();
		ahi.setAllDiscussionVip(myuser.getAllDiscussionVip());
		ahi.setAllDiscussionVip_1(other);
		AllDiscussionHate ah = new AllDiscussionHate();
		ah.setId(ahi);
		ah.setDeleteFlag(0);
		mainDao.save(ah);
		return true;
		}
		else
		{
			AllDiscussionHate ah=(AllDiscussionHate) list.get(0);
			ah.setDeleteFlag(0);
			mainDao.update(ah);
			return true;
		}
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public boolean changegood(int goodFlag, String cardId) {
		// TODO Auto-generated method stub
		AllDiscussionCrads card = (AllDiscussionCrads) mainDao.get(AllDiscussionCrads.class, cardId);
		if (goodFlag == 1) {
			int i = card.getGoods();
			card.setGoods(++i);
			AllDiscussionConversation adc = card.getAllDiscussionConversation();
			int j = adc.getHot();
			j = j + 80;
			adc.setHot(j);
			card.setAllDiscussionConversation(adc);
			mainDao.update(adc);
			mainDao.update(card);
		} else {
			int i = card.getGoods();
			card.setGoods(--i);
			AllDiscussionConversation adc = card.getAllDiscussionConversation();
			int j = adc.getHot();
			j = j + 80;
			adc.setHot(j);
			card.setAllDiscussionConversation(adc);
			mainDao.update(adc);
			mainDao.update(card);
		}

		return true;
	}

	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public AllDiscussionVip personal(String personalId) {

		String hql = "from AllDiscussionVip adc where adc.vipid='" + personalId + "'";
		List list = mainDao.queryData(hql);
		AllDiscussionVip personal = (AllDiscussionVip) list.get(0);
		return personal;

	}

	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public List showHate(AllDiscussionVip vip) {
		String hql = "from AllDiscussionHate ah where ah.id.allDiscussionVip='" + vip.getVipid()
				+ "' and ah.deleteFlag=0";
		return mainDao.queryData(hql);

	}
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public List isHate(AllDiscussionVip myVip, AllDiscussionVip vip) {
		String hql = "from AllDiscussionHate ah where ah.id.allDiscussionVip.vipid='" + vip.getVipid()
				+ "' and ah.id.allDiscussionVip_1.vipid='" + myVip.getVipid() + "' and ah.deleteFlag=0";
		List list = mainDao.queryData(hql);
		return list;

	}
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public List allHate(AllDiscussionVip myVip, AllDiscussionVip vip)
	{
		String hql = "from AllDiscussionHate ah where ah.id.allDiscussionVip.vipid='" + myVip.getVipid()
		+ "' and ah.id.allDiscussionVip_1.vipid='" + vip.getVipid() + "'";
     List list = mainDao.queryData(hql);
    return list;

		
	}
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public AllDiscussionCrads getCard(String cardId)
	{
		return (AllDiscussionCrads) mainDao.get(AllDiscussionCrads.class, cardId);
		
	}
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public List showHatePersonal(AllDiscussionVip myVip)
	{
		String hql = "from AllDiscussionHate ah where ah.id.allDiscussionVip.vipid='" + myVip.getVipid()
		+ "' and ah.deleteFlag=0";
     List list = mainDao.queryData(hql);
    return list;
		
		
	}

}
