package com.ad.service.chat_system.impl;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ad.dao.chat_system.ChatDAO;
import com.ad.service.chat_system.ChatManager;
import com.model.AllDiscussionChat;
import com.model.AllDiscussionChatObject;
import com.model.AllDiscussionChatObjectId;
import com.model.AllDiscussionCrads;
import com.model.AllDiscussionUser;
import com.model.AllDiscussionVip;
import com.opensymphony.xwork2.ActionContext;
@Transactional(rollbackFor = Exception.class)
public class ChatManagerImpl implements ChatManager {

	@Resource
	private ChatDAO chatDao;
	
	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public boolean addChatObject(AllDiscussionUser myuser, String vipId, AllDiscussionChat adC) {
		// TODO Auto-generated method stub
		AllDiscussionVip other = (AllDiscussionVip) chatDao.get(AllDiscussionVip.class,vipId);
		AllDiscussionVip myVip=myuser.getAllDiscussionVip();
		List list = this.isChatObject(myVip, other);
		if (list.isEmpty()) {
			AllDiscussionChatObject aco = new AllDiscussionChatObject();
			AllDiscussionChatObjectId acoid = new AllDiscussionChatObjectId();
			AllDiscussionChatObject acoOther = new AllDiscussionChatObject();
			AllDiscussionChatObjectId acoidOther = new AllDiscussionChatObjectId();
			acoidOther.setAllDiscussionVip(other);
			acoidOther.setAllDiscussionVip_1(myVip);
			acoOther.setDeletFlag(0);
			acoOther.setIsFriends(1);
			acoOther.setStatusFriend(0);
			adC.setParentId("0");
			aco.setDeletFlag(0);
			aco.setStatusFriend(0);
			acoid.setAllDiscussionVip(myuser.getAllDiscussionVip());// ��
			acoid.setAllDiscussionVip_1(other);// ��
			acoid.setAllDiscussionChat(adC);
			acoidOther.setAllDiscussionChat(adC);
			aco.setId(acoid);
			aco.setIsFriends(1);
			acoOther.setId(acoidOther);
			Timestamp d = new Timestamp(System.currentTimeMillis());
			aco.setUpdateTime(d);
			acoOther.setUpdateTime(d);
			acoOther.setTidings(1);
			aco.setTidings(0);
			chatDao.save(adC);
			chatDao.save(acoOther);
			chatDao.save(aco);
		}
		else
		{
			AllDiscussionChatObject aco =(AllDiscussionChatObject) list.get(0);
			AllDiscussionChat adc=aco.getId().getAllDiscussionChat();
			adC.setParentId(adc.getChatId());
			List listOther = this.isChatObject(other,myVip);
			AllDiscussionChatObject acoOther=(AllDiscussionChatObject) listOther.get(0);
			int i=acoOther.getTidings();
			i=i+1;
			acoOther.setTidings(i);
			chatDao.update(acoOther);
			chatDao.save(adC);
		}
		return true;

	}
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public List isChatObject(AllDiscussionVip myVip, AllDiscussionVip other) {
		String hql = "from AllDiscussionChatObject aco where aco.id.allDiscussionVip.vipid='" + myVip.getVipid()
				+ "' and aco.id.allDiscussionVip_1.vipid='" + other.getVipid() + "' and aco.deletFlag=0";
		List list = chatDao.queryData(hql);
		return list;

	}
	@Transactional(propagation = Propagation.REQUIRED)
	public List showChat(String vipId)
	{
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		AllDiscussionVip other = (AllDiscussionVip) chatDao.get(AllDiscussionVip.class,vipId);
		List list=this.isChatObject(adu.getAllDiscussionVip(),other);
		if(list.isEmpty())
		{
			return list;
		}
		else
		{
		AllDiscussionChatObject adco=(AllDiscussionChatObject) list.get(0);
		adco.setTidings(0);
		String hql="from AllDiscussionChat adc where adc.parentId='"+adco.getId().getAllDiscussionChat().getChatId()+"' and adc.deleteFlag=0";
		List myList=chatDao.queryData(hql);
		chatDao.update(adco);
		return myList;
		}	
		
		
	}
	
	
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public List getTitle(String vipId)
	{
		AllDiscussionVip other = (AllDiscussionVip) chatDao.get(AllDiscussionVip.class,vipId);
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		String hql = "select aco.id.allDiscussionChat from AllDiscussionChatObject aco where aco.id.allDiscussionVip.vipid='" +adu.getAllDiscussionVip().getVipid()
		+ "' and aco.id.allDiscussionVip_1.vipid='" + other.getVipid() + "' and aco.deletFlag=0 ";
		List list=chatDao.queryData(hql);
		return list;
	}
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public List showPrivatePersonal(int MaxResults)
	{
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		String hql="select aco.id.allDiscussionVip_1 from AllDiscussionChatObject aco where aco.id.allDiscussionVip.vipid='"+adu.getAllDiscussionVip().getVipid()+"' and aco.deletFlag=0 and aco.isFriends=1";
		List list=chatDao.Maxquery(MaxResults, hql);
		return list;
	}
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public List allShowPrivatePersonal()
	{
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		String hql="select aco.id.allDiscussionVip_1 from AllDiscussionChatObject aco where aco.id.allDiscussionVip.vipid='"+adu.getAllDiscussionVip().getVipid()+"' and aco.deletFlag=0 and aco.isFriends=1";
		List list=chatDao.queryData(hql);
		return list;
	}
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public long privatePersonalCount()
	{
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		String hql="select count(*) from AllDiscussionChatObject aco where aco.id.allDiscussionVip.vipid='"+adu.getAllDiscussionVip().getVipid()+"' and aco.deletFlag=0 and aco.isFriends=1";
		List list=chatDao.queryData(hql);
		long l = Long.valueOf(String.valueOf(list.get(0))).longValue();
		return l;
	}
	
	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public boolean addFriend(AllDiscussionUser myuser, String vipId, AllDiscussionChat adC) {
		// TODO Auto-generated method stub
		AllDiscussionVip other = (AllDiscussionVip) chatDao.get(AllDiscussionVip.class,vipId);
		AllDiscussionVip myVip=myuser.getAllDiscussionVip();
		List list = this.isChatObject(myVip, other);
		if (list.isEmpty()) {
			AllDiscussionChatObject aco = new AllDiscussionChatObject();
			AllDiscussionChatObjectId acoid = new AllDiscussionChatObjectId();
			AllDiscussionChatObject acoOther = new AllDiscussionChatObject();
			AllDiscussionChatObjectId acoidOther = new AllDiscussionChatObjectId();
			acoidOther.setAllDiscussionVip(other);
			acoidOther.setAllDiscussionVip_1(myVip);
			acoOther.setDeletFlag(0);
			acoOther.setIsFriends(1);
			acoOther.setStatusFriend(1);
			adC.setParentId("0");
			aco.setDeletFlag(0);
			aco.setStatusFriend(0);
			acoid.setAllDiscussionVip(myuser.getAllDiscussionVip());// ��
			acoid.setAllDiscussionVip_1(other);// ��
			acoid.setAllDiscussionChat(adC);
			acoidOther.setAllDiscussionChat(adC);
			aco.setId(acoid);
			aco.setIsFriends(1);
			acoOther.setId(acoidOther);
			Timestamp d = new Timestamp(System.currentTimeMillis());
			aco.setUpdateTime(d);
			acoOther.setUpdateTime(d);
			acoOther.setTidings(1);
			aco.setTidings(0);
			chatDao.save(adC);
			chatDao.save(acoOther);
			chatDao.save(aco);
		}
		else
		{
			AllDiscussionChatObject aco =(AllDiscussionChatObject) list.get(0);
			AllDiscussionChat adc=aco.getId().getAllDiscussionChat();
			adC.setParentId(adc.getChatId());
			List listOther = this.isChatObject(other,myVip);
			AllDiscussionChatObject acoOther=(AllDiscussionChatObject) listOther.get(0);
			int i=acoOther.getTidings();
			i=i+1;
			acoOther.setTidings(i);
			acoOther.setStatusFriend(1);
			acoOther.setIsFriends(1);
			aco.setStatusFriend(0);
			aco.setIsFriends(1);
			chatDao.update(aco);
			chatDao.update(acoOther);
			chatDao.save(adC);
			
		}
		return true;


	}

	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public List showFriend(int MaxResults) {
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		String hql = "select aco.id.allDiscussionVip_1 from AllDiscussionChatObject aco where aco.id.allDiscussionVip.vipid='"
				+ adu.getAllDiscussionVip().getVipid() + "' and aco.isFriends=0 and aco.deletFlag=0 and aco.statusFriend=0";
		List friendList = chatDao.Maxquery(MaxResults, hql);
		return friendList;
	}
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public List allShowFriend()
	{
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		String hql = "select aco.id.allDiscussionVip_1 from AllDiscussionChatObject aco where aco.id.allDiscussionVip.vipid='"
				+ adu.getAllDiscussionVip().getVipid() + "' and aco.isFriends=0 and aco.deletFlag=0 and aco.statusFriend=0";
		List friendList = chatDao.queryData(hql);
		return friendList;
	}
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public long friendCount()
	{

		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		String hql = "select count(*) from AllDiscussionChatObject aco where aco.id.allDiscussionVip.vipid='"
				+ adu.getAllDiscussionVip().getVipid() + "' and aco.isFriends=0 and aco.deletFlag=0 and aco.statusFriend=0";
		List list = chatDao.queryData(hql);
		long l = Long.valueOf(String.valueOf(list.get(0))).longValue();
		return l;

	}
	public void updateFriend(int friendFlag,String vipId)
	{
		AllDiscussionVip other = (AllDiscussionVip) chatDao.get(AllDiscussionVip.class,vipId);
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		
		if(friendFlag==0)
		{
			String hql = "from AllDiscussionChatObject aco where aco.id.allDiscussionVip.vipid='" + adu.getAllDiscussionVip().getVipid()
			+ "' and aco.id.allDiscussionVip_1.vipid='" + other.getVipid() + "' and aco.deletFlag=0 and aco.isFriends=1 and aco.statusFriend=1";
			List list=chatDao.queryData(hql);
			AllDiscussionChatObject aco=(AllDiscussionChatObject) list.get(0);
			aco.setIsFriends(0);
			aco.setStatusFriend(0);
			String hql1 = "from AllDiscussionChatObject aco where aco.id.allDiscussionVip.vipid='" + other.getVipid()
					+ "' and aco.id.allDiscussionVip_1.vipid='" + adu.getAllDiscussionVip().getVipid() + "' and aco.deletFlag=0 and aco.isFriends=1 and aco.statusFriend=0";
			list=chatDao.queryData(hql1);
			AllDiscussionChatObject aco1=(AllDiscussionChatObject) list.get(0);
			aco1.setStatusFriend(0);
			aco1.setIsFriends(0);
			chatDao.update(aco1);
			chatDao.update(aco);
		}else
		{
			String hql = "from AllDiscussionChatObject aco where aco.id.allDiscussionVip.vipid='" + adu.getAllDiscussionVip().getVipid()
					+ "' and aco.id.allDiscussionVip_1.vipid='" + other.getVipid() + "' and aco.deletFlag=0 aco.isFriends=1 and aco.statusFriend=1";
					List list=chatDao.queryData(hql);
					AllDiscussionChatObject aco=(AllDiscussionChatObject) list.get(0);
					aco.setIsFriends(1);
					aco.setStatusFriend(0);
					String hql1 = "from AllDiscussionChatObject aco where aco.id.allDiscussionVip.vipid='" + other.getVipid()
							+ "' and aco.id.allDiscussionVip_1.vipid='" + adu.getAllDiscussionVip().getVipid() + "' and aco.deletFlag=0 and  aco.isFriends=1 and aco.statusFriend=0";
					list=chatDao.queryData(hql1);
					AllDiscussionChatObject aco1=(AllDiscussionChatObject) list.get(0);
					aco1.setStatusFriend(0);
					aco1.setIsFriends(1);
					chatDao.update(aco1);
					chatDao.update(aco);	
		}
		
	}
	public void deleteFriend(String vipid)
		{
			AllDiscussionVip other = (AllDiscussionVip) chatDao.get(AllDiscussionVip.class,vipid);
			ActionContext actionContext = ActionContext.getContext();
			Map session = actionContext.getSession();
			AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
			String hql = "from AllDiscussionChatObject aco where aco.id.allDiscussionVip.vipid='" + adu.getAllDiscussionVip().getVipid()
					+ "' and aco.id.allDiscussionVip_1.vipid='" + other.getVipid() + "' and aco.deletFlag=0 and aco.isFriends=0 and aco.statusFriend=0";
					List list=chatDao.queryData(hql);
					AllDiscussionChatObject aco=(AllDiscussionChatObject) list.get(0);
					aco.setIsFriends(1);
					aco.setStatusFriend(0);
					String hql1 = "from AllDiscussionChatObject aco where aco.id.allDiscussionVip.vipid='" + other.getVipid()
							+ "' and aco.id.allDiscussionVip_1.vipid='" + adu.getAllDiscussionVip().getVipid() + "' and aco.deletFlag=0 and aco.isFriends=0 and aco.statusFriend=0";
					list=chatDao.queryData(hql1);
					AllDiscussionChatObject aco1=(AllDiscussionChatObject) list.get(0);
					aco1.setStatusFriend(0);
					aco1.setIsFriends(1);
					chatDao.update(aco1);
					chatDao.update(aco);
			
		}
	
	
}
