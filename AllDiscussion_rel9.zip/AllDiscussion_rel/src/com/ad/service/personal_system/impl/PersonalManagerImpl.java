package com.ad.service.personal_system.impl;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ad.dao.personal_system.PersonalDAO;
import com.ad.service.personal_system.PersonalManager;
import com.model.AllDiscussionHate;
import com.model.AllDiscussionSign;
import com.model.AllDiscussionUser;
import com.model.AllDiscussionVip;
import com.opensymphony.xwork2.ActionContext;

@Transactional(rollbackFor = Exception.class)
public class PersonalManagerImpl implements PersonalManager {

	@Resource
	private PersonalDAO personalDao;

	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public AllDiscussionUser updateUser() {

		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		adu = (AllDiscussionUser) personalDao.get(AllDiscussionUser.class, adu.getUserId());
		session.put("user", adu);
		return adu;
	}

	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public List showMyCards(int FirstResult, int MaxResults) {

		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		String hql = "from AllDiscussionCrads adc where adc.allDiscussionVip.vipid in("
				+ "select aco.id.allDiscussionVip_1.vipid from AllDiscussionChatObject aco where aco.id.allDiscussionVip.vipid='"+adu.getAllDiscussionVip().getVipid()+"' and aco.isFriends=0 and aco.deletFlag=0 and aco.statusFriend=0 )"
						+ " and adc.deleteFlag=0 order by adc.nowTime Desc";
		List list = personalDao.queryPageData(hql, FirstResult, MaxResults);
		return list;

	}

	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public long getMyCount() {
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		String hql = "select count(*) from AllDiscussionCrads adc where adc.allDiscussionVip.vipid in("
				+ "select aco.id.allDiscussionVip_1.vipid from AllDiscussionChatObject aco where aco.id.allDiscussionVip.vipid='"+adu.getAllDiscussionVip().getVipid()+"' and aco.isFriends=0 and aco.deletFlag=0 and aco.statusFriend=0 )"
						+ " and adc.deleteFlag=0 ";
		List list = personalDao.queryData(hql);
		long l = Long.valueOf(String.valueOf(list.get(0))).longValue();
		return l;
	}

	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public List showCollection() {
		AllDiscussionUser adu = this.updateUser();
		Set set = adu.getAllDiscussionVip().getAllDiscussionCradses_1();
		Iterator it = set.iterator();
		List list2 = new ArrayList();
		int i = 0;
		if (set.size() <= 5) {
			while (it.hasNext() && i < set.size()) {
				list2.add(it.next());
				i++;
			}
		} else {
			while (it.hasNext() && i <= 5) {
				list2.add(it.next());
				i++;
			}

		}
		return list2;

	}

	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public int getCountCollection() {
		AllDiscussionUser adu = this.updateUser();
		Set set = adu.getAllDiscussionVip().getAllDiscussionCradses_1();
		return set.size();
	}

	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public Set showAllCollection() {
		AllDiscussionUser adu = this.updateUser();
		Set set = adu.getAllDiscussionVip().getAllDiscussionCradses_1();
		return set;
	}

	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public List cardTidings(int MaxResults) {
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");

		String hql = "from AllDiscussionCrads adc where adc.allDiscussionVip.vipid='"
				+ adu.getAllDiscussionVip().getVipid()
				+ "'and adc.deleteFlag=0 and adc.tidings>0 order by adc.nowTime Desc";
		List list = personalDao.Maxquery(MaxResults, hql);
		// System.out.println(list);
		return list;
	}

	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public long getCardTidings() {
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		String hql = "select count(*) from AllDiscussionCrads adc where adc.allDiscussionVip.vipid='"
				+ adu.getAllDiscussionVip().getVipid() + "'and adc.deleteFlag=0 and adc.tidings>0";
		List list = personalDao.queryData(hql);
		long l = Long.valueOf(String.valueOf(list.get(0))).longValue();
		return l;
	}
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public List showAllCardTidings()
	{
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");

		String hql = "from AllDiscussionCrads adc where adc.allDiscussionVip.vipid='"
				+ adu.getAllDiscussionVip().getVipid()
				+ "'and adc.deleteFlag=0 and adc.tidings>0 order by adc.nowTime Desc";
		List list = personalDao.queryData(hql);
		// System.out.println(list);
		return list;
	}
	

	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public List showRecord(int MaxResults) {
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		String hql = "select ar.id.allDiscussionCrads from AllDiscussionRecrod ar where ar.id.allDiscussionVip.vipid='"
				+ adu.getAllDiscussionVip().getVipid() + "' order by ar.time Desc";
		List list = personalDao.Maxquery(MaxResults, hql);
		return list;
	}

	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public long getRecordCount() {
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		String hql = "select count(*) from AllDiscussionRecrod ar where ar.id.allDiscussionVip.vipid='"
				+ adu.getAllDiscussionVip().getVipid() + "'";
		List list = personalDao.queryData(hql);
		long l = Long.valueOf(String.valueOf(list.get(0))).longValue();
		return l;
	}
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public List showAllRecord()
	{
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		String hql = "select ar.id.allDiscussionCrads from AllDiscussionRecrod ar where ar.id.allDiscussionVip.vipid='"
				+ adu.getAllDiscussionVip().getVipid() + "' order by ar.time Desc";
		List list = personalDao.queryData(hql);
		return list;
	}
	

	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public List showHate(int MaxResults) {
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		String hql = "select ah.id.allDiscussionVip_1 from AllDiscussionHate ah where ah.id.allDiscussionVip.vipid='"
				+ adu.getAllDiscussionVip().getVipid() + "' and ah.deleteFlag=0";
		List list = personalDao.Maxquery(MaxResults, hql);
		return list;

	}

	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public long getHateCount() {
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		String hql = "select count(*) from AllDiscussionHate ah where ah.id.allDiscussionVip.vipid='"
				+ adu.getAllDiscussionVip().getVipid() + "' and ah.deleteFlag=0";
		List list = personalDao.queryData(hql);
		long l = Long.valueOf(String.valueOf(list.get(0))).longValue();
		return l;
	}

	@Transactional(propagation = Propagation.REQUIRED)
	public void deleteHate(String vipId) {
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		String hql = "from AllDiscussionHate ah where ah.id.allDiscussionVip.vipid='"
				+ adu.getAllDiscussionVip().getVipid() + "' and ah.deleteFlag=0 and ah.id.allDiscussionVip_1='" + vipId
				+ "'";
		List list = personalDao.queryData(hql);
		AllDiscussionHate ah = (AllDiscussionHate) list.get(0);
		ah.setDeleteFlag(1);
		personalDao.update(ah);
	}
	public List showAllHate()
	{
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		String hql = "select ah.id.allDiscussionVip_1 from AllDiscussionHate ah where ah.id.allDiscussionVip.vipid='"
				+ adu.getAllDiscussionVip().getVipid() + "' and ah.deleteFlag=0";
		List list = personalDao.queryData(hql);
		return list;
	}

	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public int isSign() {
		AllDiscussionUser adu = this.updateUser();
		AllDiscussionSign ads = adu.getAllDiscussionVip().getAllDiscussionSign();
		Timestamp t = new Timestamp(System.currentTimeMillis());
		Date d = ads.getLastTime();
		Date nd = t;
		Calendar cal = Calendar.getInstance();
		cal.setTime(d);
		int day = cal.get(Calendar.DATE);// ��ȡ��
		int year = cal.get(Calendar.YEAR);
		int month = cal.get(Calendar.MONTH) + 1;
		cal.setTime(nd);
		int nowday = cal.get(Calendar.DATE);
		int nowyear = cal.get(Calendar.YEAR);
		int nowmonth = cal.get(Calendar.MONTH) + 1;
		// System.out.println(day);
		// System.out.println(year);
		// System.out.println(month);
		if ((nowyear - year) > 0) {
			return 1;
		} else {
			if ((nowmonth - year) > 0) {
				return 1;
			} else {
				if ((nowday - day) > 0) {
					return 1;
				} else {
					return 0;
				}

			}

		}

	}

	@Transactional(propagation = Propagation.REQUIRED)
	public int addSign() {
		AllDiscussionUser adu = this.updateUser();
		AllDiscussionSign ads = adu.getAllDiscussionVip().getAllDiscussionSign();
		Timestamp t = new Timestamp(System.currentTimeMillis());
		Date d = ads.getLastTime();
		Date nd = t;
		Calendar cal = Calendar.getInstance();
		cal.setTime(d);
		int day = cal.get(Calendar.DATE);// ��ȡ��
		int year = cal.get(Calendar.YEAR);
		int month = cal.get(Calendar.MONTH) + 1;
		cal.setTime(nd);
		int nowday = cal.get(Calendar.DATE);
		int nowyear = cal.get(Calendar.YEAR);
		int nowmonth = cal.get(Calendar.MONTH) + 1;
		// System.out.println(day);
		// System.out.println(year);
		// System.out.println(month);
		if ((nowyear - year) > 0) {

			ads.setLastTime(t);
			ads.setCountNumber(1);
			personalDao.update(ads);
			personalDao.update(adu.getAllDiscussionVip());
			personalDao.update(adu);

		} else {
			if ((nowmonth - year) > 0) {
				ads.setLastTime(t);
				ads.setCountNumber(1);
				personalDao.update(ads);
				personalDao.update(adu.getAllDiscussionVip());
				personalDao.update(adu);
			} else {
				if ((nowday - day) > 1) {
					ads.setLastTime(t);
					ads.setCountNumber(1);
					personalDao.update(ads);
					personalDao.update(adu.getAllDiscussionVip());
					personalDao.update(adu);
				} else {
					ads.setLastTime(t);
					int i = ads.getCountNumber();
					i = i + 1;
					ads.setCountNumber(i);
					System.out.println("where??");
					personalDao.update(ads);
					personalDao.update(adu.getAllDiscussionVip());
					personalDao.update(adu);
				}
			}
		}
return 1;
	}
	@Transactional(propagation = Propagation.REQUIRED)
	public void modifyPersonal(AllDiscussionUser adu)
	{
		personalDao.update(adu.getAllDiscussionVip().getAllDiscussionHead());
		personalDao.update(adu.getAllDiscussionVip());
		personalDao.update(adu);
	}
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public List chatPrivateTidings(int MaxResults)
	{
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		String hql="from AllDiscussionChatObject aco where aco.id.allDiscussionVip.vipid='" +adu.getAllDiscussionVip().getVipid()
				+ "' and aco.deletFlag=0 and aco.tidings>0 order by aco.updateTime Desc";
		List list=personalDao.Maxquery(MaxResults, hql);
		return list;
	}
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public List allChatPrivateTidings()
	{
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		String hql="from AllDiscussionChatObject aco where aco.id.allDiscussionVip.vipid='" +adu.getAllDiscussionVip().getVipid()
				+ "' and aco.deletFlag=0 and aco.tidings>0 order by aco.updateTime Desc";
		List list=personalDao.queryData(hql);
		return list;
	}
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public long getChatTidingsCount()
	{
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		String hql="select count(*) from AllDiscussionChatObject aco where aco.id.allDiscussionVip.vipid='" +adu.getAllDiscussionVip().getVipid()
				+ "' and aco.deletFlag=0 and aco.tidings>0 ";
		List list = personalDao.queryData(hql);
		long l = Long.valueOf(String.valueOf(list.get(0))).longValue();
		return l;
	}
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public List showFriendTidings(int MaxResults)
	{

		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		String hql="from AllDiscussionChatObject aco where aco.id.allDiscussionVip.vipid='"+adu.getAllDiscussionVip().getVipid()+"'and aco.deletFlag=0 and aco.isFriends=1 and aco.statusFriend=1 order by aco.updateTime Desc";
		List list=personalDao.Maxquery(MaxResults, hql);
		return list;
	}
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public long getCountFriendTidings()
	{
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		String hql=" select count(*) from AllDiscussionChatObject aco where aco.id.allDiscussionVip.vipid='"+adu.getAllDiscussionVip().getVipid()+"'and aco.deletFlag=0 and aco.isFriends=1 and aco.statusFriend=1";
		List list=personalDao.queryData(hql);
		long l = Long.valueOf(String.valueOf(list.get(0))).longValue();
		return l;
	}
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public List allFriendTidings()
	{
		ActionContext actionContext = ActionContext.getContext();
		Map session = actionContext.getSession();
		AllDiscussionUser adu = (AllDiscussionUser) session.get("user");
		String hql="from AllDiscussionChatObject aco where aco.id.allDiscussionVip.vipid='"+adu.getAllDiscussionVip().getVipid()+"'and aco.deletFlag=1 and aco.isFriends=0 and aco.statusFriend=1 order by aco.updateTime Desc";
		List list=personalDao.queryData(hql);
		return list;	
	}
	
}
