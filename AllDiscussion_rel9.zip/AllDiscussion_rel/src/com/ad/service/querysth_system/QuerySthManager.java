package com.ad.service.querysth_system;

import java.util.List;

public interface QuerySthManager {
	public List queryCards(String data,int MaxResults);
	public List queryConversation(String data, int MaxResults);
	public List queryPersonal(String data);
}
