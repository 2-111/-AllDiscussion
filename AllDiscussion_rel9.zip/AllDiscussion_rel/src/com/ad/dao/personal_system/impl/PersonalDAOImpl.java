package com.ad.dao.personal_system.impl;

import java.io.Serializable;
import java.util.List;

import javax.annotation.Resource;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import com.ad.dao.personal_system.PersonalDAO;

public class PersonalDAOImpl implements PersonalDAO {

	@Resource
	private SessionFactory sessionFactory;
	@Override
	public boolean save(Object obj) {
		// TODO Auto-generated method stub
		try{
			Session session=sessionFactory.getCurrentSession();
			session.save(obj);
			return true;
		}
		catch(Exception e)
		{
			
			e.printStackTrace();
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			return false;
		}
	}

	@Override
	public boolean update(Object obj) {
		// TODO Auto-generated method stub
		try{
			Session session=sessionFactory.getCurrentSession();
			session.update(obj);
			return true;
		}
		catch(Exception e)
		{
			
			e.printStackTrace();
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			return false;
		}
	}

	@Override
	public List queryPageData(String hql, int FirstResult, int MaxResults) {
		// TODO Auto-generated method stub
		try{
			Session session=sessionFactory.getCurrentSession();
			Query q=session.createQuery(hql);
			q.setMaxResults(MaxResults);
			q.setFirstResult(FirstResult);
			List list=q.list();
			return list;
		}
		catch(Exception e)
		{
			
			e.printStackTrace();
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			return null;
		}
	}

	@Override
	public List queryData(String hql) {
		// TODO Auto-generated method stub
		try{
			Session session=sessionFactory.getCurrentSession();
			Query q=session.createQuery(hql);
			List list=q.list();
			return list;
		}
		catch(Exception e)
		{
			
			e.printStackTrace();
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			return null;
		}
		
	}

	@Override
	public long countData() {
		// TODO Auto-generated method stub
		try{
			Session session=sessionFactory.getCurrentSession();
			String hql="count(*) from AllDiscussionCrads adc";
			Query q=session.createQuery(hql);
			List list=q.list();
			long j=0;
			for(int i=0;i<list.size();i++)
			{
				j=(long) list.get(i);
			}
			return j;
		}
		catch(Exception e)
		{
			
			e.printStackTrace();
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			return 0;
		}
	}
	public void clear(){
		Session session=sessionFactory.getCurrentSession();
		session.clear();
		session.flush();
	}
	public void merge(Object obj)
	{
		Session session=sessionFactory.getCurrentSession();
		session.merge(obj);
		
	}
	public Object get(Class a,Serializable b)
	{
		Session session=sessionFactory.getCurrentSession();
		return session.get(a, b);
		
	}
	public void sqlDelete(String sql)
	{
		Session session=sessionFactory.getCurrentSession();
		int i=session.createSQLQuery(sql).executeUpdate();
		System.out.println(i);
		session.flush();
		
	}
	public List Maxquery(int MaxResults,String hql)
	{
		try{
			Session session=sessionFactory.getCurrentSession();
			Query q=session.createQuery(hql);
			q.setMaxResults(MaxResults);
			List list=q.list();
			return list;
		}
		catch(Exception e)
		{
			
			e.printStackTrace();
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			return null;
		}
		
		
		
		
		
	}

}
