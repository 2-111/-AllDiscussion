package com.ad.service.main_system;

import java.util.List;

import com.ad.dao.main_system.MainDAO;
import com.model.AllDiscussionCrads;
import com.model.AllDiscussionUser;
import com.model.AllDiscussionVip;

public interface MainManager {
	
	public List showConversation(int FirstResult,int MaxResults);
	public List showCard(int FirstResult,int MaxResults,String parentId);
	public boolean collectionCC(String cardId,AllDiscussionUser user);
	public boolean makePublicCon(AllDiscussionCrads card);
	public boolean makePublicCra_Remar(String cardId,AllDiscussionCrads card);
	public long getCountConversation();
	public long getCountCard(String cardId);
	public boolean addFriend(AllDiscussionUser myuser,AllDiscussionVip other);
	public boolean addChatObject();
	public boolean addHateObject();
	public boolean changegood();
	public boolean cancelCollection(String cardId,AllDiscussionUser user);
	public boolean deleteFriend(AllDiscussionUser myuser,AllDiscussionVip other);
	public List title(String cardId);
	public List showRemark(int FirstResult,int MaxResults,String parentId);
}
