package com.ad.service.main_system.impl;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ad.dao.main_system.MainDAO;
import com.ad.service.main_system.MainManager;
import com.model.AllDiscussionChatObject;
import com.model.AllDiscussionChatObjectId;
import com.model.AllDiscussionConversation;
import com.model.AllDiscussionCrads;
import com.model.AllDiscussionUser;
import com.model.AllDiscussionVip;
import com.opensymphony.xwork2.ActionContext;
@Transactional(rollbackFor = Exception.class)
public class MainManagerImpl implements MainManager {
	@Resource
	private MainDAO mainDao;
	@Override
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public List showConversation(int FirstResult, int MaxResults) {
		// TODO Auto-generated method stub
		String hql="from AllDiscussionCrads adc where adc.parentId='0' and deleteFlag='0' order by adc.allDiscussionConversation.hot Desc";
		List info=mainDao.queryPageData(hql, FirstResult, MaxResults);
		return info;
	}

	@Override
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public List showCard(int FirstResult, int MaxResults,String parentId) {
		// TODO Auto-generated method stub
		String hql="from AllDiscussionCrads adc where adc.deleteFlag='0' and adc.parentId='"+parentId+"'order by adc.updateTime Desc";
		List info=mainDao.queryPageData(hql, FirstResult, MaxResults);
		return info;
	}
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public List title(String cardId)
	{
		String hql="from AllDiscussionCrads adc where adc.cardsId='"+cardId+"'";
		List list=mainDao.queryData(hql);
		return list;
	}
	public List showRemark(int FirstResult,int MaxResults,String parentId)
	{
		String hql="from AllDiscussionCrads adc where adc.deleteFlag='0' and adc.parentId='"+parentId+"'order by adc.nowTime";
		List info=mainDao.queryPageData(hql, FirstResult, MaxResults);
		return info;
		
	}
	
	
	
	
	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public boolean collectionCC(String cardId, AllDiscussionUser user) {
		// TODO Auto-generated method stub
		String hql="from AllDiscussionCrads adc where adc.cardsId='"+cardId+"'";
		List list=mainDao.queryData(hql);
		AllDiscussionCrads card=(AllDiscussionCrads) list.get(0);
		AllDiscussionVip vip=user.getAllDiscussionVip();
		vip.getAllDiscussionCradses_1().add(card);
		card.getAllDiscussionVips().add(vip);
		mainDao.update(card);
		mainDao.update(vip);
		return true;
	}
	@Transactional(propagation = Propagation.REQUIRED)
	public boolean cancelCollection(String cardId,AllDiscussionUser user)
	{
		String hql="from AllDiscussionCrads adc where adc.cardsId='"+cardId+"'";
		List list=mainDao.queryData(hql);
		AllDiscussionCrads card=(AllDiscussionCrads) list.get(0);
		AllDiscussionVip vip=user.getAllDiscussionVip();
		vip.getAllDiscussionCradses_1().remove(card);
		card.getAllDiscussionVips().remove(vip);
		mainDao.update(card);
		mainDao.update(vip);
		return true;
	}

	@Override
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public boolean makePublicCon(AllDiscussionCrads card) {
		// TODO Auto-generated method stub
		mainDao.save(card.getAllDiscussionConversation());
		mainDao.save(card);
		return true;
	
		
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public boolean makePublicCra_Remar(String cardId,AllDiscussionCrads mycard) {
		// TODO Auto-generated method stub	
		String hql="from AllDiscussionCrads adc where adc.cardsId='"+cardId+"'";
		List list=mainDao.queryData(hql);
		AllDiscussionCrads card=(AllDiscussionCrads) list.get(0);
		int i=card.getRelyN();
		i=i+1;
		card.setRelyN(i);
		mycard.setAllDiscussionConversation(card.getAllDiscussionConversation());
		int hot=card.getAllDiscussionConversation().getHot();
		hot=hot+100;
		card.getAllDiscussionConversation().setHot(hot);
		Timestamp d = new Timestamp(System.currentTimeMillis()); 
		card.setUpdateTime(d);
		mainDao.update(card.getAllDiscussionConversation());
		mainDao.update(card);
		mainDao.save(mycard);
		return true;
	}

	@Override
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public long getCountConversation() {
		// TODO Auto-generated method stub
		String hql="select count(*) from AllDiscussionCrads adc where adc.deleteFlag='0' and adc.parentId='0'";
		List list=mainDao.queryData(hql);
		long l = Long.valueOf(String.valueOf(list.get(0))).longValue();
		return l;
	}
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public long getCountCard(String cardId) {
		// TODO Auto-generated method stub
		String hql="select count(*) from AllDiscussionCrads adc where adc.deleteFlag='0' and adc.parentId='"+cardId+"'";
		List list=mainDao.queryData(hql);
		long l = Long.valueOf(String.valueOf(list.get(0))).longValue();
		return l;
	}

	@Override
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public boolean addFriend(AllDiscussionUser myuser,AllDiscussionVip other) {
		// TODO Auto-generated method stub
		AllDiscussionChatObject aco=new AllDiscussionChatObject();
		AllDiscussionChatObjectId acoid=new AllDiscussionChatObjectId();
		aco.setDeletFlag(0);
		acoid.setAllDiscussionVip(myuser.getAllDiscussionVip());
		acoid.setAllDiscussionVip_1(other);
		aco.setId(acoid);
		aco.setIsFriends(0);
		mainDao.save(aco);
		return false;
	}
	
	public boolean deleteFriend(AllDiscussionUser myuser,AllDiscussionVip other) {
		// TODO Auto-generated method stub
		
		return false;
	}
	@Override
	public boolean addChatObject() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean addHateObject() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean changegood() {
		// TODO Auto-generated method stub
		return false;
	}

}
