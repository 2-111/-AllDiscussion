package com.ad.service.login_system.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ad.dao.login_system.LoginDAO;
import com.ad.service.login_system.LoginManager;
import com.model.AllDiscussionUser;
import com.opensymphony.xwork2.ActionContext;

@Transactional(rollbackFor = Exception.class)
public class LoginManagerImpl implements LoginManager {

	@Resource
	private LoginDAO loginDao;

	@Override
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public boolean loginUser(String username, String pwd) {
		// TODO Auto-generated method stub
		String hql = "from AllDiscussionUser adu where adu.userName='" + username + "' and adu.passWord='" + pwd + "'";
		List list = loginDao.queryData(hql);
		Map session = ActionContext.getContext().getSession();
		if (list.isEmpty()) {
			return false;
		} else {
			session.put("user", (AllDiscussionUser)list.get(0));
			return true;
		}

	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public boolean registerUser(AllDiscussionUser user) {
		// TODO Auto-generated method stub
		String hql = "from AllDiscussionUser adu where adu.userName='" + user.getUserName() + "'";
		List list = loginDao.queryData(hql);
		if (list.isEmpty()) {
			loginDao.save(user.getAllDiscussionVip());
			loginDao.save(user);
			return true;
		} else {
			return false;

		}
	}

}
