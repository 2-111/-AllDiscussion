package com.ad.service.back_management;

import java.util.List;

import com.model.AllDiscussionUser;

public interface BackManagement {
	public boolean modifyUser(String userId, String userName, String passWord);

	public boolean deleteUser(String userId);

	public List selectAllUser();

	public boolean addUser(AllDiscussionUser user);

	public List selectAllCards();

	public boolean deleteCards(String cardsId);

	public List selectAllConversation();

	public boolean deleteConversation(String conversationId);
}
