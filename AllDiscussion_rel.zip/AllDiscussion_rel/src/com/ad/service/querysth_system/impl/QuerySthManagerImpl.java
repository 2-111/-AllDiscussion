package com.ad.service.querysth_system.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ad.dao.querysth_system.QuerySthDAO;
import com.ad.service.querysth_system.QuerySthManager;
@Transactional(rollbackFor = Exception.class)
public class QuerySthManagerImpl implements QuerySthManager {

	@Resource
	private QuerySthDAO querySthDao;
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public List queryCards(String data,int MaxResults)
	{
		return querySthDao.queryCard(data, MaxResults);
	}
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public List queryConversation(String data, int MaxResults)
	{
		return querySthDao.queryConversation(data, MaxResults);
	}
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public List queryPersonal(String data)
	{
		return querySthDao.queryPersonal(data);
	}
}
