package com.ad.service.chat_system;

import java.util.List;

import com.model.AllDiscussionChat;
import com.model.AllDiscussionUser;
import com.model.AllDiscussionVip;

public interface ChatManager {
	public boolean addChatObject(AllDiscussionUser myuser, String vipId, AllDiscussionChat adC);
	public List isChatObject(AllDiscussionVip myVip, AllDiscussionVip other);
	public List showChat(String vipId);
	public List getTitle(String vipId);
	public List showPrivatePersonal(int MaxResults);
	public boolean addFriend(AllDiscussionUser myuser, String vipId, AllDiscussionChat adC);
	public List showFriend(int MaxResults);
	public void updateFriend(int friendFlag,String vipId);
	public List allShowFriend();
	public long friendCount();
	public List allShowPrivatePersonal();
	public long privatePersonalCount();
	public void deleteFriend(String vipid);
}
