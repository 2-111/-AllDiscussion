package com.ad.dao.querysth_system.impl;

import java.io.Serializable;
import java.util.List;

import javax.annotation.Resource;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import com.ad.dao.querysth_system.QuerySthDAO;

public class QuerySthDAOImpl implements QuerySthDAO {
	@Resource
	private SessionFactory sessionFactory;

	public List queryCard(String data,int MaxResults)
	{
		Session session =sessionFactory.getCurrentSession();
		String hql="from AllDiscussionCrads adc where (adc.title like:title or adc.context like:context)and adc.level=1 order by adc.updateTime Desc";
		Query query=session.createQuery(hql);
		query.setString("title","%"+data+"%" );
		query.setString("context", "%"+data+"%");
		query.setMaxResults(MaxResults);
		List list=query.list();
		return list;
	}

	
	public List queryConversation(String data ,int MaxResults)
	{
		Session session =sessionFactory.getCurrentSession();
		String hql="from AllDiscussionCrads adc where (adc.allDiscussionConversation.title like:title or adc.allDiscussionConversation.context like:context) and adc.level=0 order by adc.allDiscussionConversation.hot Desc";
		Query query=session.createQuery(hql);
		query.setString("title","%"+data+"%" );
		query.setString("context", "%"+data+"%");
		query.setMaxResults(MaxResults);
		List list=query.list();
		return list;
	}
	public List queryPersonal(String data)
	{
		Session session =sessionFactory.getCurrentSession();
		String hql="from AllDiscussionVip adv where adv.name like:name";
		Query query=session.createQuery(hql);
		query.setString("name", "%"+data+"%");
		List list=query.list();
		return list;
	}
}
