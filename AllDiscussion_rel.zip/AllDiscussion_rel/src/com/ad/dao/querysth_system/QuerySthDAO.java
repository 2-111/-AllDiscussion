package com.ad.dao.querysth_system;

import java.io.Serializable;
import java.util.List;

public interface QuerySthDAO {
	public List queryCard(String data,int MaxResults);
	public List queryConversation(String data ,int MaxResults);
	public List queryPersonal(String data);
}
