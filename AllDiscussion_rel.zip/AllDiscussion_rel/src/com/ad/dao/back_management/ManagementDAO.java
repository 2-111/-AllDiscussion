package com.ad.dao.back_management;

import java.io.Serializable;
import java.util.List;

public interface ManagementDAO {
	public List selectAllUser();

	public List selectAllCards(String sql);

	public boolean save(Object obj);

	public List queryData(String hql);

	public boolean deleteUser(String sql);

	public boolean deleteCards(String sql);

	public boolean update(String sql);

	public List selectAllConversation(String sql);

	public boolean deleteConversation(String sql,String conversationId);

}
