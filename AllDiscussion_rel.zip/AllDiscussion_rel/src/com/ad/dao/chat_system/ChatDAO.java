package com.ad.dao.chat_system;

import java.io.Serializable;
import java.util.List;

public interface ChatDAO {
	public boolean save(Object obj);
	public boolean update(Object obj);
	public List queryPageData(String hql,int FirstResult,int MaxResults);
	public List queryData(String hql);
	public long countData();
	public void clear();
	public void merge(Object obj);
	public Object get(Class a,Serializable b);
	public void sqlDelete(String sql);
	public List Maxquery(int MaxResults,String hql);

}
