package com.ad.dao.login_system;

import java.util.List;

import com.model.AllDiscussionUser;



public interface LoginDAO {

	public boolean save(Object obj);
	public List queryData(String hql);
}
