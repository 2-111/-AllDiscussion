package com.ad.action.querysth_system;

import java.util.List;

import javax.annotation.Resource;

import com.ad.service.querysth_system.QuerySthManager;
import com.opensymphony.xwork2.ActionSupport;

public class QuerySthAction extends ActionSupport {

	@Resource
	private QuerySthManager querySthManager;
	
	private String data;
	private List results;
	private int typeFlag;
	public String showResult()
	{
		if(typeFlag==0)
		{
			results=querySthManager.queryConversation(data,10);
			
		}
		else if(typeFlag==1)
		{
			results=querySthManager.queryCards(data, 10);
			
		}else
		{
			
			results=querySthManager.queryPersonal(data);
		}
		
		
		return "showResult_success";
	}
	public QuerySthManager getQuerySthManager() {
		return querySthManager;
	}
	public void setQuerySthManager(QuerySthManager querySthManager) {
		this.querySthManager = querySthManager;
	}
	public List getResults() {
		return results;
	}
	public void setResults(List results) {
		this.results = results;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	public int getTypeFlag() {
		return typeFlag;
	}
	public void setTypeFlag(int typeFlag) {
		this.typeFlag = typeFlag;
	}

	
}
