package com.ad.interceptor;

import java.util.Map;

import com.ad.action.login_system.LoginAction;
import com.model.AllDiscussionUser;
import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.AbstractInterceptor;

public class CheckInterceptor extends AbstractInterceptor {

	
	@Override
	public String intercept(ActionInvocation arg0) throws Exception {
		// TODO Auto-generated method stub
		Object action =arg0.getAction();
		if(action instanceof LoginAction)
		{
			return arg0.invoke();
			
			
		}
		else
		{
			Map session =arg0.getInvocationContext().getSession();
			String pwd=(String) session.get("pwd");
			if(session.get("user")==null)
			{
				return Action.LOGIN;
			}
			else
			{
				return arg0.invoke();
				
			}
			
		}
		
		
		
		
		
		
	}

}
