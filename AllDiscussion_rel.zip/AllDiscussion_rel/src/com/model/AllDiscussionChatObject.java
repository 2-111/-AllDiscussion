package com.model;

import java.sql.Timestamp;

/**
 * AllDiscussionChatObject entity. @author MyEclipse Persistence Tools
 */

public class AllDiscussionChatObject implements java.io.Serializable {

	// Fields

	private AllDiscussionChatObjectId id;
	private Integer deletFlag;
	private Integer isFriends;
	private Timestamp updateTime;
	private Integer tidings;
	private Integer statusFriend;

	// Constructors

	/** default constructor */
	public AllDiscussionChatObject() {
	}

	/** minimal constructor */
	public AllDiscussionChatObject(AllDiscussionChatObjectId id) {
		this.id = id;
	}

	/** full constructor */
	public AllDiscussionChatObject(AllDiscussionChatObjectId id, Integer deletFlag, Integer isFriends,Timestamp updateTime,Integer tidings,Integer statusFriend) {
		this.id = id;
		this.deletFlag = deletFlag;
		this.isFriends = isFriends;
		this.updateTime=updateTime;
		this.tidings=tidings;
		this.statusFriend=statusFriend;
	}

	// Property accessors

	public AllDiscussionChatObjectId getId() {
		return this.id;
	}

	public void setId(AllDiscussionChatObjectId id) {
		this.id = id;
	}

	public Integer getDeletFlag() {
		return this.deletFlag;
	}

	public void setDeletFlag(Integer deletFlag) {
		this.deletFlag = deletFlag;
	}

	public Integer getIsFriends() {
		return this.isFriends;
	}

	public void setIsFriends(Integer isFriends) {
		this.isFriends = isFriends;
	}

	public Timestamp getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Timestamp updateTime) {
		this.updateTime = updateTime;
	}

	public Integer getTidings() {
		return tidings;
	}

	public void setTidings(Integer tidings) {
		this.tidings = tidings;
	}

	public Integer getStatusFriend() {
		return statusFriend;
	}

	public void setStatusFriend(Integer statusFriend) {
		this.statusFriend = statusFriend;
	}
	

}