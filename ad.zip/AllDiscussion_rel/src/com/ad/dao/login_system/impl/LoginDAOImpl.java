package com.ad.dao.login_system.impl;

import java.util.List;

import javax.annotation.Resource;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.ad.dao.login_system.LoginDAO;
import com.model.AllDiscussionUser;

public class LoginDAOImpl implements LoginDAO {

	@Resource
	private SessionFactory sessionFactory;

	@Override
	public boolean save(Object obj) {
		// TODO Auto-generated method stub
		try {
			Session session = sessionFactory.getCurrentSession();
			session.save(obj);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public List queryData(String hql) {
		// TODO Auto-generated method stub

		try{
			Session sess = sessionFactory.getCurrentSession();
			Query q = sess.createQuery(hql);
			List list=q.list();

			return list;
			}catch(Exception e)
			{
				e.printStackTrace();
				return null;
				
				
			}
	}

}
