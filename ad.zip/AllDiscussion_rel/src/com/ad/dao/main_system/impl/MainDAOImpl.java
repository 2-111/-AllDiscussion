package com.ad.dao.main_system.impl;

import java.util.List;

import javax.annotation.Resource;

import org.hibernate.SessionFactory;

import com.ad.dao.main_system.MainDAO;
import com.model.AllDiscussionCrads;

public class MainDAOImpl implements MainDAO {

	@Resource
	private SessionFactory sessionFactory;
	@Override
	public boolean save(Object obj) {
		// TODO Auto-generated method stub
		
		return false;
	}

	@Override
	public boolean update(AllDiscussionCrads card) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List queryPageData(String hql, int FirstResult, int MaxResults) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List queryData(String hql) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long countData() {
		// TODO Auto-generated method stub
		return 0;
	}

}
