package com.ad.action.login_system;

import java.sql.Timestamp;

import javax.annotation.Resource;

import com.ad.service.login_system.LoginManager;
import com.model.AllDiscussionUser;
import com.model.AllDiscussionVip;
import com.opensymphony.xwork2.ActionSupport;

public class LoginAction extends ActionSupport {
	@Resource
	private LoginManager loginManager;
	private String username;
	private String pwd;
	
	private String name;
	private String sex;
	private String email;
	private Long phoneNumber;
	public Long getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(Long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String login()
	{
		if(loginManager.loginUser(username, pwd))
		{
			
			return "login_success";
		}else
		{
			return "login_error";
			
		}
	}
	public String register()
	{
		AllDiscussionVip vip=new AllDiscussionVip();
		AllDiscussionUser user=new AllDiscussionUser();
		vip.setName(name);
		vip.setEmail(email);
		vip.setSex(sex);
		vip.setPrivate_(0);
		vip.setPhoneNumber(phoneNumber);
		vip.setDeletwFlag(0);
		user.setDeleteFlag(0);
		user.setPassWord(pwd);
		user.setUserName(username);
		Timestamp d = new Timestamp(System.currentTimeMillis()); 
		user.setNowTime(d);
		user.setAllDiscussionVip(vip);
		if(loginManager.registerUser(user))
		{
			
			return "register_success";
		}
		else
		{
			return "register_error";
		}
		
	}
	
	
	
	
	

}
